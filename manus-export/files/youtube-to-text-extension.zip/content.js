// YouTube To Text - Content Script
// Injects a sidebar panel into YouTube watch pages

(function() {
  'use strict';

  // Prevent double injection
  if (document.getElementById('ytt-sidebar')) return;

  let currentVideoId = null;
  let transcriptData = null;
  let currentLang = 'en';
  let sidebarVisible = true;
  let darkMode = true;
  let searchQuery = '';

  // ============================================================
  // SIDEBAR HTML
  // ============================================================
  function createSidebar() {
    const sidebar = document.createElement('div');
    sidebar.id = 'ytt-sidebar';
    sidebar.innerHTML = `
      <div class="ytt-header">
        <div class="ytt-logo">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M12 2L2 7l10 5 10-5-10-5z"/>
            <path d="M2 17l10 5 10-5"/>
            <path d="M2 12l10 5 10-5"/>
          </svg>
          <span>YouTube To Text</span>
        </div>
        <div class="ytt-header-actions">
          <button id="ytt-theme-toggle" class="ytt-icon-btn" title="Toggle theme">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <circle cx="12" cy="12" r="5"/>
              <path d="M12 1v2M12 21v2M4.22 4.22l1.42 1.42M18.36 18.36l1.42 1.42M1 12h2M21 12h2M4.22 19.78l1.42-1.42M18.36 5.64l1.42-1.42"/>
            </svg>
          </button>
          <button id="ytt-settings-btn" class="ytt-icon-btn" title="Settings">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <circle cx="12" cy="12" r="3"/>
              <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"/>
            </svg>
          </button>
          <button id="ytt-close-btn" class="ytt-icon-btn" title="Close panel">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <line x1="18" y1="6" x2="6" y2="18"/>
              <line x1="6" y1="6" x2="18" y2="18"/>
            </svg>
          </button>
        </div>
      </div>

      <!-- Settings Panel (hidden by default) -->
      <div id="ytt-settings-panel" class="ytt-settings-panel" style="display:none;">
        <h3>Settings</h3>
        <label for="ytt-api-key">Gemini API Key</label>
        <div class="ytt-api-key-row">
          <input type="password" id="ytt-api-key" placeholder="Enter your Gemini API key..." />
          <button id="ytt-save-api-key" class="ytt-btn ytt-btn-primary">Save</button>
        </div>
        <p class="ytt-hint">Get a free API key at <a href="https://aistudio.google.com/apikey" target="_blank">Google AI Studio</a></p>
        <button id="ytt-settings-close" class="ytt-btn ytt-btn-secondary">Close Settings</button>
      </div>

      <!-- Tabs -->
      <div class="ytt-tabs">
        <button class="ytt-tab active" data-tab="transcription">Transcription</button>
        <button class="ytt-tab" data-tab="summary">Summary</button>
      </div>

      <!-- Language & Actions Bar -->
      <div class="ytt-actions-bar">
        <div class="ytt-lang-selector">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <circle cx="12" cy="12" r="10"/>
            <line x1="2" y1="12" x2="22" y2="12"/>
            <path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/>
          </svg>
          <select id="ytt-lang-select">
            <option value="en">EN</option>
          </select>
        </div>
        <div class="ytt-action-buttons">
          <button id="ytt-search-btn" class="ytt-icon-btn" title="Search transcript">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <circle cx="11" cy="11" r="8"/>
              <line x1="21" y1="21" x2="16.65" y2="16.65"/>
            </svg>
          </button>
          <button id="ytt-copy-btn" class="ytt-icon-btn" title="Copy transcript">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <rect x="9" y="9" width="13" height="13" rx="2" ry="2"/>
              <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>
            </svg>
          </button>
          <button id="ytt-download-btn" class="ytt-icon-btn" title="Download transcript">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
              <polyline points="7 10 12 15 17 10"/>
              <line x1="12" y1="15" x2="12" y2="3"/>
            </svg>
          </button>
        </div>
      </div>

      <!-- Search Bar (hidden by default) -->
      <div id="ytt-search-bar" class="ytt-search-bar" style="display:none;">
        <input type="text" id="ytt-search-input" placeholder="Search transcript..." />
        <span id="ytt-search-count"></span>
      </div>

      <!-- Content Area -->
      <div id="ytt-content" class="ytt-content">
        <div id="ytt-transcription-tab" class="ytt-tab-content active">
          <div id="ytt-transcript-list" class="ytt-transcript-list">
            <div class="ytt-loading">
              <div class="ytt-spinner"></div>
              <p>Click to load transcript...</p>
              <button id="ytt-load-btn" class="ytt-btn ytt-btn-primary">Load Transcript</button>
            </div>
          </div>
        </div>
        <div id="ytt-summary-tab" class="ytt-tab-content">
          <div id="ytt-summary-content" class="ytt-summary-content">
            <div class="ytt-loading">
              <p>Load transcript first, then generate a summary.</p>
              <button id="ytt-summarize-btn" class="ytt-btn ytt-btn-primary" disabled>Generate Summary</button>
            </div>
          </div>
        </div>
      </div>

      <!-- Resize Handle -->
      <div id="ytt-resize-handle" class="ytt-resize-handle"></div>
    `;

    document.body.appendChild(sidebar);
    return sidebar;
  }

  // ============================================================
  // INITIALIZATION
  // ============================================================
  const sidebar = createSidebar();
  applyTheme();
  setupEventListeners();
  detectVideoChange();

  // ============================================================
  // EVENT LISTENERS
  // ============================================================
  function setupEventListeners() {
    // Toggle sidebar from extension icon click
    document.addEventListener('yt-to-text-toggle', () => {
      sidebarVisible = !sidebarVisible;
      sidebar.style.display = sidebarVisible ? 'flex' : 'none';
    });

    // Close button
    document.getElementById('ytt-close-btn').addEventListener('click', () => {
      sidebarVisible = false;
      sidebar.style.display = 'none';
    });

    // Theme toggle
    document.getElementById('ytt-theme-toggle').addEventListener('click', () => {
      darkMode = !darkMode;
      applyTheme();
    });

    // Settings
    document.getElementById('ytt-settings-btn').addEventListener('click', () => {
      const panel = document.getElementById('ytt-settings-panel');
      panel.style.display = panel.style.display === 'none' ? 'block' : 'none';
      // Load existing key
      chrome.runtime.sendMessage({ action: 'getApiKey' }, (response) => {
        if (response && response.apiKey) {
          document.getElementById('ytt-api-key').value = response.apiKey;
        }
      });
    });

    document.getElementById('ytt-settings-close').addEventListener('click', () => {
      document.getElementById('ytt-settings-panel').style.display = 'none';
    });

    document.getElementById('ytt-save-api-key').addEventListener('click', () => {
      const key = document.getElementById('ytt-api-key').value.trim();
      chrome.runtime.sendMessage({ action: 'saveApiKey', apiKey: key }, () => {
        showToast('API key saved!');
        document.getElementById('ytt-settings-panel').style.display = 'none';
      });
    });

    // Tabs
    document.querySelectorAll('.ytt-tab').forEach(tab => {
      tab.addEventListener('click', () => {
        document.querySelectorAll('.ytt-tab').forEach(t => t.classList.remove('active'));
        document.querySelectorAll('.ytt-tab-content').forEach(c => c.classList.remove('active'));
        tab.classList.add('active');
        document.getElementById(`ytt-${tab.dataset.tab}-tab`).classList.add('active');
      });
    });

    // Language selector
    document.getElementById('ytt-lang-select').addEventListener('change', (e) => {
      currentLang = e.target.value;
      loadTranscript();
    });

    // Load transcript button
    document.getElementById('ytt-load-btn').addEventListener('click', loadTranscript);

    // Summarize button
    document.getElementById('ytt-summarize-btn').addEventListener('click', generateSummary);

    // Copy button
    document.getElementById('ytt-copy-btn').addEventListener('click', copyTranscript);

    // Download button
    document.getElementById('ytt-download-btn').addEventListener('click', downloadTranscript);

    // Search
    document.getElementById('ytt-search-btn').addEventListener('click', () => {
      const bar = document.getElementById('ytt-search-bar');
      bar.style.display = bar.style.display === 'none' ? 'flex' : 'none';
      if (bar.style.display === 'flex') {
        document.getElementById('ytt-search-input').focus();
      }
    });

    document.getElementById('ytt-search-input').addEventListener('input', (e) => {
      searchQuery = e.target.value.toLowerCase();
      renderTranscript();
    });

    // Resize handle
    setupResize();
  }

  // ============================================================
  // VIDEO DETECTION
  // ============================================================
  function getVideoId() {
    const urlParams = new URLSearchParams(window.location.search);
    return urlParams.get('v');
  }

  function detectVideoChange() {
    const checkVideo = () => {
      const newVideoId = getVideoId();
      if (newVideoId && newVideoId !== currentVideoId) {
        currentVideoId = newVideoId;
        transcriptData = null;
        resetUI();
      }
    };

    checkVideo();

    // Watch for YouTube SPA navigation
    const observer = new MutationObserver(() => {
      checkVideo();
    });
    observer.observe(document.querySelector('title') || document.head, {
      childList: true,
      subtree: true,
      characterData: true
    });

    // Also listen for popstate/pushstate
    window.addEventListener('yt-navigate-finish', checkVideo);
  }

  function resetUI() {
    document.getElementById('ytt-transcript-list').innerHTML = `
      <div class="ytt-loading">
        <div class="ytt-spinner"></div>
        <p>New video detected. Click to load transcript.</p>
        <button id="ytt-load-btn" class="ytt-btn ytt-btn-primary">Load Transcript</button>
      </div>
    `;
    document.getElementById('ytt-load-btn').addEventListener('click', loadTranscript);

    document.getElementById('ytt-summary-content').innerHTML = `
      <div class="ytt-loading">
        <p>Load transcript first, then generate a summary.</p>
        <button id="ytt-summarize-btn" class="ytt-btn ytt-btn-primary" disabled>Generate Summary</button>
      </div>
    `;
    document.getElementById('ytt-summarize-btn').addEventListener('click', generateSummary);

    // Reset language selector
    const langSelect = document.getElementById('ytt-lang-select');
    langSelect.innerHTML = '<option value="en">EN</option>';
  }

  // ============================================================
  // TRANSCRIPT LOADING
  // ============================================================
  async function loadTranscript() {
    if (!currentVideoId) {
      showToast('No video detected.');
      return;
    }

    const listEl = document.getElementById('ytt-transcript-list');
    listEl.innerHTML = `
      <div class="ytt-loading">
        <div class="ytt-spinner spinning"></div>
        <p>Loading transcript...</p>
      </div>
    `;

    try {
      const response = await new Promise((resolve, reject) => {
        chrome.runtime.sendMessage(
          { action: 'fetchTranscript', videoId: currentVideoId, lang: currentLang },
          (resp) => {
            if (chrome.runtime.lastError) {
              reject(new Error(chrome.runtime.lastError.message));
            } else if (resp && resp.success) {
              resolve(resp.data);
            } else {
              reject(new Error(resp?.error || 'Unknown error'));
            }
          }
        );
      });

      transcriptData = response;

      // Populate language selector
      const langSelect = document.getElementById('ytt-lang-select');
      langSelect.innerHTML = '';
      response.languages.forEach(lang => {
        const option = document.createElement('option');
        option.value = lang.code;
        option.textContent = lang.code.toUpperCase() + (lang.isGenerated ? ' (auto)' : '');
        if (lang.code === response.selectedLanguage) option.selected = true;
        langSelect.appendChild(option);
      });

      // Enable summarize button
      const sumBtn = document.getElementById('ytt-summarize-btn');
      if (sumBtn) sumBtn.disabled = false;

      renderTranscript();
      showToast('Transcript loaded!');
    } catch (err) {
      listEl.innerHTML = `
        <div class="ytt-loading ytt-error">
          <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <circle cx="12" cy="12" r="10"/>
            <line x1="15" y1="9" x2="9" y2="15"/>
            <line x1="9" y1="9" x2="15" y2="15"/>
          </svg>
          <p>${escapeHtml(err.message)}</p>
          <button id="ytt-load-btn" class="ytt-btn ytt-btn-primary">Retry</button>
        </div>
      `;
      document.getElementById('ytt-load-btn').addEventListener('click', loadTranscript);
    }
  }

  // ============================================================
  // RENDER TRANSCRIPT
  // ============================================================
  function renderTranscript() {
    if (!transcriptData || !transcriptData.transcript) return;

    const listEl = document.getElementById('ytt-transcript-list');
    listEl.innerHTML = '';

    const items = transcriptData.transcript;
    const searchCountEl = document.getElementById('ytt-search-count');
    let matchCount = 0;

    items.forEach((item, index) => {
      const matchesSearch = !searchQuery || item.text.toLowerCase().includes(searchQuery);
      if (searchQuery && matchesSearch) matchCount++;

      const div = document.createElement('div');
      div.className = 'ytt-transcript-item' + (matchesSearch ? '' : ' ytt-hidden');
      if (searchQuery && matchesSearch) div.classList.add('ytt-highlight');

      const timestamp = formatTime(item.start);
      let displayText = escapeHtml(item.text);

      // Highlight search matches
      if (searchQuery && matchesSearch) {
        const regex = new RegExp(`(${escapeRegex(searchQuery)})`, 'gi');
        displayText = displayText.replace(regex, '<mark>$1</mark>');
      }

      div.innerHTML = `
        <span class="ytt-timestamp" data-time="${item.start}">${timestamp}</span>
        <span class="ytt-text">${displayText}</span>
      `;

      // Click timestamp to seek video
      div.querySelector('.ytt-timestamp').addEventListener('click', () => {
        seekVideo(item.start);
      });

      listEl.appendChild(div);
    });

    if (searchQuery) {
      searchCountEl.textContent = `${matchCount} match${matchCount !== 1 ? 'es' : ''}`;
    } else {
      searchCountEl.textContent = '';
    }
  }

  // ============================================================
  // AI SUMMARY
  // ============================================================
  async function generateSummary() {
    if (!transcriptData || !transcriptData.transcript) {
      showToast('Load transcript first.');
      return;
    }

    const contentEl = document.getElementById('ytt-summary-content');
    contentEl.innerHTML = `
      <div class="ytt-loading">
        <div class="ytt-spinner spinning"></div>
        <p>Generating AI summary...</p>
      </div>
    `;

    // Switch to summary tab
    document.querySelectorAll('.ytt-tab').forEach(t => t.classList.remove('active'));
    document.querySelectorAll('.ytt-tab-content').forEach(c => c.classList.remove('active'));
    document.querySelector('.ytt-tab[data-tab="summary"]').classList.add('active');
    document.getElementById('ytt-summary-tab').classList.add('active');

    try {
      // Get API key
      const keyResponse = await new Promise((resolve) => {
        chrome.runtime.sendMessage({ action: 'getApiKey' }, resolve);
      });

      if (!keyResponse || !keyResponse.apiKey) {
        contentEl.innerHTML = `
          <div class="ytt-loading ytt-error">
            <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/>
              <line x1="12" y1="9" x2="12" y2="13"/>
              <line x1="12" y1="17" x2="12.01" y2="17"/>
            </svg>
            <p>Gemini API key required for AI summaries.</p>
            <p class="ytt-hint">Click the gear icon to add your free API key from <a href="https://aistudio.google.com/apikey" target="_blank">Google AI Studio</a></p>
            <button id="ytt-open-settings-from-summary" class="ytt-btn ytt-btn-primary">Open Settings</button>
          </div>
        `;
        document.getElementById('ytt-open-settings-from-summary').addEventListener('click', () => {
          document.getElementById('ytt-settings-panel').style.display = 'block';
          chrome.runtime.sendMessage({ action: 'getApiKey' }, (response) => {
            if (response && response.apiKey) {
              document.getElementById('ytt-api-key').value = response.apiKey;
            }
          });
        });
        return;
      }

      // Build full transcript text
      const fullText = transcriptData.transcript.map(item =>
        `[${formatTime(item.start)}] ${item.text}`
      ).join('\n');

      const response = await new Promise((resolve, reject) => {
        chrome.runtime.sendMessage(
          { action: 'summarize', text: fullText, apiKey: keyResponse.apiKey },
          (resp) => {
            if (chrome.runtime.lastError) {
              reject(new Error(chrome.runtime.lastError.message));
            } else if (resp && resp.success) {
              resolve(resp.data);
            } else {
              reject(new Error(resp?.error || 'Unknown error'));
            }
          }
        );
      });

      // Render the summary with basic markdown parsing
      contentEl.innerHTML = `
        <div class="ytt-summary-text">${renderMarkdown(response)}</div>
        <div class="ytt-summary-actions">
          <button id="ytt-copy-summary" class="ytt-btn ytt-btn-secondary">Copy Summary</button>
          <button id="ytt-regenerate" class="ytt-btn ytt-btn-primary">Regenerate</button>
        </div>
      `;

      document.getElementById('ytt-copy-summary').addEventListener('click', () => {
        navigator.clipboard.writeText(response).then(() => showToast('Summary copied!'));
      });

      document.getElementById('ytt-regenerate').addEventListener('click', generateSummary);

    } catch (err) {
      contentEl.innerHTML = `
        <div class="ytt-loading ytt-error">
          <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <circle cx="12" cy="12" r="10"/>
            <line x1="15" y1="9" x2="9" y2="15"/>
            <line x1="9" y1="9" x2="15" y2="15"/>
          </svg>
          <p>${escapeHtml(err.message)}</p>
          <button id="ytt-summarize-btn" class="ytt-btn ytt-btn-primary">Retry</button>
        </div>
      `;
      document.getElementById('ytt-summarize-btn').addEventListener('click', generateSummary);
    }
  }

  // ============================================================
  // COPY & DOWNLOAD
  // ============================================================
  function copyTranscript() {
    if (!transcriptData || !transcriptData.transcript) {
      showToast('No transcript loaded.');
      return;
    }

    const text = transcriptData.transcript.map(item =>
      `[${formatTime(item.start)}] ${item.text}`
    ).join('\n');

    navigator.clipboard.writeText(text).then(() => {
      showToast('Transcript copied to clipboard!');
    }).catch(() => {
      showToast('Failed to copy.');
    });
  }

  function downloadTranscript() {
    if (!transcriptData || !transcriptData.transcript) {
      showToast('No transcript loaded.');
      return;
    }

    const text = transcriptData.transcript.map(item =>
      `[${formatTime(item.start)}] ${item.text}`
    ).join('\n');

    const title = transcriptData.videoTitle || 'transcript';
    const blob = new Blob([text], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${sanitizeFilename(title)}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    showToast('Transcript downloaded!');
  }

  // ============================================================
  // UTILITY FUNCTIONS
  // ============================================================
  function formatTime(seconds) {
    const h = Math.floor(seconds / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    const s = Math.floor(seconds % 60);
    if (h > 0) {
      return `${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
    }
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  }

  function seekVideo(time) {
    const video = document.querySelector('video');
    if (video) {
      video.currentTime = time;
      video.play();
    }
  }

  function escapeHtml(str) {
    const div = document.createElement('div');
    div.textContent = str;
    return div.innerHTML;
  }

  function escapeRegex(str) {
    return str.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  }

  function sanitizeFilename(name) {
    return name.replace(/[^a-z0-9\s\-_]/gi, '').replace(/\s+/g, '_').substring(0, 100);
  }

  function renderMarkdown(text) {
    return text
      .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
      .replace(/\*(.+?)\*/g, '<em>$1</em>')
      .replace(/^### (.+)$/gm, '<h4>$1</h4>')
      .replace(/^## (.+)$/gm, '<h3>$1</h3>')
      .replace(/^# (.+)$/gm, '<h2>$1</h2>')
      .replace(/^\* (.+)$/gm, '<li>$1</li>')
      .replace(/^- (.+)$/gm, '<li>$1</li>')
      .replace(/(<li>.*<\/li>)/gs, '<ul>$1</ul>')
      .replace(/<\/ul>\s*<ul>/g, '')
      .replace(/\n\n/g, '</p><p>')
      .replace(/\n/g, '<br>')
      .replace(/^/, '<p>')
      .replace(/$/, '</p>');
  }

  function showToast(message) {
    const existing = document.getElementById('ytt-toast');
    if (existing) existing.remove();

    const toast = document.createElement('div');
    toast.id = 'ytt-toast';
    toast.className = 'ytt-toast';
    toast.textContent = message;
    sidebar.appendChild(toast);

    setTimeout(() => toast.classList.add('show'), 10);
    setTimeout(() => {
      toast.classList.remove('show');
      setTimeout(() => toast.remove(), 300);
    }, 2500);
  }

  function applyTheme() {
    if (darkMode) {
      sidebar.classList.add('ytt-dark');
      sidebar.classList.remove('ytt-light');
    } else {
      sidebar.classList.remove('ytt-dark');
      sidebar.classList.add('ytt-light');
    }
  }

  // ============================================================
  // RESIZE HANDLE
  // ============================================================
  function setupResize() {
    const handle = document.getElementById('ytt-resize-handle');
    let isResizing = false;
    let startX, startWidth;

    handle.addEventListener('mousedown', (e) => {
      isResizing = true;
      startX = e.clientX;
      startWidth = sidebar.offsetWidth;
      document.body.style.userSelect = 'none';
      e.preventDefault();
    });

    document.addEventListener('mousemove', (e) => {
      if (!isResizing) return;
      const diff = startX - e.clientX;
      const newWidth = Math.max(300, Math.min(700, startWidth + diff));
      sidebar.style.width = newWidth + 'px';
    });

    document.addEventListener('mouseup', () => {
      if (isResizing) {
        isResizing = false;
        document.body.style.userSelect = '';
      }
    });
  }

})();
