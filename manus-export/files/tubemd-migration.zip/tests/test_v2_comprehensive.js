// Comprehensive V2 Test Suite for TubeMD
// Tests all features: transcript extraction, markdown generation, skill prompts,
// trial logic, multi-provider, copy/download, language support, etc.

const fs = require('fs');
const path = require('path');

let passed = 0, failed = 0, skipped = 0;

function test(name, fn) {
  try {
    fn();
    passed++;
    console.log(`  ✅ ${name}`);
  } catch (e) {
    failed++;
    console.log(`  ❌ ${name}: ${e.message}`);
  }
}

function skip(name, reason) {
  skipped++;
  console.log(`  ⏭️  ${name} (${reason})`);
}

function assert(condition, msg) {
  if (!condition) throw new Error(msg || 'Assertion failed');
}

// ============================================================
// 1. FILE STRUCTURE TESTS
// ============================================================
console.log('\n📁 FILE STRUCTURE');

const requiredFiles = [
  'manifest.json', 'background.js', 'content.js', 'content.css',
  'popup.html', 'popup.js', 'popup.css',
  'options.html', 'options.js', 'options.css',
  'icons/icon16.png', 'icons/icon48.png', 'icons/icon128.png',
  'README.md'
];

requiredFiles.forEach(f => {
  test(`File exists: ${f}`, () => {
    assert(fs.existsSync(path.join('/home/ubuntu/youtube-to-text-extension', f)), `Missing: ${f}`);
  });
});

// ============================================================
// 2. MANIFEST TESTS
// ============================================================
console.log('\n📋 MANIFEST');

const manifest = JSON.parse(fs.readFileSync('/home/ubuntu/youtube-to-text-extension/manifest.json', 'utf8'));

test('Manifest V3', () => assert(manifest.manifest_version === 3));
test('Version is 1.0.0', () => assert(manifest.version === '1.0.0'));
test('Has popup action', () => assert(manifest.action?.default_popup === 'popup.html'));
test('Has content scripts', () => assert(manifest.content_scripts?.length > 0));
test('Content script matches YouTube', () => {
  assert(manifest.content_scripts[0].matches.some(m => m.includes('youtube.com')));
});
test('Has background service worker', () => assert(manifest.background?.service_worker === 'background.js'));
test('Has options page', () => assert(manifest.options_page === 'options.html'));
test('Has storage permission', () => assert(manifest.permissions.includes('storage')));
test('Has activeTab permission', () => assert(manifest.permissions.includes('activeTab')));
test('Has keyboard shortcut', () => assert(manifest.commands?.['toggle-panel']));
test('Icons defined', () => {
  assert(manifest.icons['16'] && manifest.icons['48'] && manifest.icons['128']);
});

// ============================================================
// 3. POPUP HTML TESTS
// ============================================================
console.log('\n🖥️  POPUP HTML');

const popupHtml = fs.readFileSync('/home/ubuntu/youtube-to-text-extension/popup.html', 'utf8');

test('Has markdown tab', () => assert(popupHtml.includes('data-format="markdown"')));
test('Has text tab', () => assert(popupHtml.includes('data-format="text"')));
test('Has summary tab', () => assert(popupHtml.includes('data-format="summary"')));
test('Has skill tab', () => assert(popupHtml.includes('data-format="skill"')));
test('Has GET TRANSCRIPTION button', () => assert(popupHtml.includes('GET TRANSCRIPTION')));
test('Has language selector', () => assert(popupHtml.includes('lang-select')));
test('Has search functionality', () => assert(popupHtml.includes('search-input')));
test('Has trial banner', () => assert(popupHtml.includes('trial-banner')));
test('Has upgrade button', () => assert(popupHtml.includes('btn-upgrade')));
test('Has contact link', () => assert(popupHtml.includes('hello@agentmatik.ai')));
test('Has version footer', () => assert(popupHtml.includes('v1.0.0')));
test('Has skill format radio buttons', () => {
  assert(popupHtml.includes('value="claude"'));
  assert(popupHtml.includes('value="manus"'));
});
test('Has generate skill button', () => assert(popupHtml.includes('btn-generate-skill')));
test('Has summarize button', () => assert(popupHtml.includes('btn-summarize')));
test('Has refresh button', () => assert(popupHtml.includes('btn-refresh')));
test('Has settings button', () => assert(popupHtml.includes('btn-settings')));
test('Has copy button', () => assert(popupHtml.includes('btn-copy')));
test('Has download button', () => assert(popupHtml.includes('btn-download')));

// ============================================================
// 4. BACKGROUND.JS TESTS
// ============================================================
console.log('\n⚙️  BACKGROUND.JS');

const bgJs = fs.readFileSync('/home/ubuntu/youtube-to-text-extension/background.js', 'utf8');

test('Has summarize handler', () => assert(bgJs.includes("case 'summarize':")));
test('Has generateSkill handler', () => assert(bgJs.includes("case 'generateSkill':")));
test('Has getSettings handler', () => assert(bgJs.includes("case 'getSettings':")));
test('Has saveSettings handler', () => assert(bgJs.includes("case 'saveSettings':")));
test('Has Gemini provider', () => assert(bgJs.includes('callGemini')));
test('Has OpenAI provider', () => assert(bgJs.includes('callOpenAI')));
test('Has Claude provider', () => assert(bgJs.includes('callClaude')));
test('Has Manus skill prompt', () => assert(bgJs.includes("skillFormat === 'manus'")));
test('Has Claude Code skill prompt', () => assert(bgJs.includes('Claude Code')));
test('Manus prompt includes SKILL.md format', () => {
  assert(bgJs.includes('name: lowercase-hyphenated'));
  assert(bgJs.includes('description:'));
});
test('Claude Code prompt includes invocation field', () => {
  assert(bgJs.includes('invocation:'));
});
test('Has unified AI caller', () => assert(bgJs.includes('async function callAI')));
test('Max output tokens set to 4096 for skills', () => assert(bgJs.includes('maxOutputTokens: 4096')));
test('Truncates text to 30000 chars', () => assert(bgJs.includes('substring(0, 30000)')));
test('Has keyboard shortcut handler', () => assert(bgJs.includes('toggle-panel')));
test('Has legacy getApiKey support', () => assert(bgJs.includes("case 'getApiKey':")));

// ============================================================
// 5. POPUP.JS TESTS
// ============================================================
console.log('\n📱 POPUP.JS');

const popupJs = fs.readFileSync('/home/ubuntu/youtube-to-text-extension/popup.js', 'utf8');

test('Has generateSkill function', () => assert(popupJs.includes('async function generateSkill')));
test('Has generateSummary function', () => assert(popupJs.includes('async function generateSummary')));
test('Has extractTranscript function', () => assert(popupJs.includes('async function extractTranscript')));
test('Has generateMarkdownContent function', () => assert(popupJs.includes('function generateMarkdownContent')));
test('Has YAML frontmatter generation', () => {
  assert(popupJs.includes("let md = '---"));
  assert(popupJs.includes('title:'));
  assert(popupJs.includes('author:'));
  assert(popupJs.includes('site: "YouTube"'));
  assert(popupJs.includes('domain: "youtube.com"'));
  assert(popupJs.includes('published:'));
  assert(popupJs.includes('duration:'));
  assert(popupJs.includes('views:'));
  assert(popupJs.includes('extracted:'));
});
test('Has trial check', () => assert(popupJs.includes('checkTrialStatus')));
test('Has 14-day trial period', () => assert(popupJs.includes('trialDays = 14')));
test('Gates premium features after trial', () => assert(popupJs.includes('gatePremiumFeatures')));
test('Skill tab is gated as PRO', () => {
  assert(popupJs.includes("querySelector('.format-tab[data-format=\"skill\"]')"));
});
test('Has skill format selector handling', () => {
  assert(popupJs.includes('skill-format'));
  assert(popupJs.includes("|| 'claude'"));
});
test('Has skill download as SKILL.md', () => assert(popupJs.includes("a.download = 'SKILL.md'")));
test('Has skill copy functionality', () => assert(popupJs.includes("showToast('Skill copied!')")));
test('Has skill regenerate', () => assert(popupJs.includes('btn-regenerate-skill')));
test('Cleans AI code fences from skill output', () => {
  assert(popupJs.includes('```(?:markdown|md|yaml)?'));
});
test('Has sendToBackground for generateSkill', () => {
  assert(popupJs.includes("sendToBackground('generateSkill'"));
});
test('Sends video metadata for skill generation', () => {
  assert(popupJs.includes('videoTitle:'));
  assert(popupJs.includes('videoUrl:'));
  assert(popupJs.includes('skillFormat'));
});
test('Has sanitizeFilename with trim', () => {
  assert(popupJs.includes("replace(/^-+|-+$/g, '')"));
});
test('Has upgrade redirect', () => assert(popupJs.includes('agentmatik.ai/tubemd-pro')));
test('Has usage counter', () => assert(popupJs.includes('incrementUsageCount')));

// ============================================================
// 6. CONTENT.JS TESTS
// ============================================================
console.log('\n📄 CONTENT.JS');

const contentJs = fs.readFileSync('/home/ubuntu/youtube-to-text-extension/content.js', 'utf8');

test('Has message handler for getVideoInfo', () => assert(contentJs.includes("'getVideoInfo'")));
test('Has message handler for getVideoMeta', () => assert(contentJs.includes("'getVideoMeta'")));
test('Has message handler for extractTranscript', () => assert(contentJs.includes("'extractTranscript'")));
test('Has message handler for seekVideo', () => assert(contentJs.includes("'seekVideo'")));
test('Has srv3 format parser', () => assert(contentJs.includes('srv3') || contentJs.includes('<p ') || contentJs.includes('parseSrv3')));
test('Has classic format parser', () => assert(contentJs.includes('<text') || contentJs.includes('parseClassic')));
test('Has decodeEntities with apos', () => assert(contentJs.includes('&apos;') || contentJs.includes('apos')));
test('Has InnerTube API fallback', () => assert(contentJs.includes('INNERTUBE') || contentJs.includes('innertube') || contentJs.includes('youtubei')));
test('Has ANDROID client', () => assert(contentJs.includes('ANDROID') || contentJs.includes('android')));
test('Has inline panel injection', () => assert(contentJs.includes('secondary') || contentJs.includes('sidebar') || contentJs.includes('panel')));
test('Has toggle event listener', () => assert(contentJs.includes('yt-to-text-toggle')));

// ============================================================
// 7. OPTIONS PAGE TESTS
// ============================================================
console.log('\n⚙️  OPTIONS PAGE');

const optionsHtml = fs.readFileSync('/home/ubuntu/youtube-to-text-extension/options.html', 'utf8');
const optionsJs = fs.readFileSync('/home/ubuntu/youtube-to-text-extension/options.js', 'utf8');

test('Options has AI provider selector', () => assert(optionsHtml.includes('aiProvider') || optionsHtml.includes('ai-provider')));
test('Options has Gemini config', () => assert(optionsHtml.includes('gemini') || optionsHtml.includes('Gemini')));
test('Options has OpenAI config', () => assert(optionsHtml.includes('openai') || optionsHtml.includes('OpenAI') || optionsHtml.includes('ChatGPT')));
test('Options has Claude config', () => assert(optionsHtml.includes('claude') || optionsHtml.includes('Claude')));
test('Options has contact email', () => assert(optionsHtml.includes('hello@agentmatik.ai')));
test('Options has version', () => assert(optionsHtml.includes('1.0.0')));
test('Options JS saves settings', () => assert(optionsJs.includes('saveSettings') || optionsJs.includes('save')));
test('Options JS loads settings', () => assert(optionsJs.includes('getSettings') || optionsJs.includes('load') || optionsJs.includes('tubeMdSettings')));

// ============================================================
// 8. FUNCTIONAL LOGIC TESTS (extracted functions)
// ============================================================
console.log('\n🔧 FUNCTIONAL LOGIC');

// Test formatTime
function formatTime(seconds) {
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = Math.floor(seconds % 60);
  if (h > 0) return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
  return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
}

test('formatTime: 0 seconds', () => assert(formatTime(0) === '00:00'));
test('formatTime: 65 seconds', () => assert(formatTime(65) === '01:05'));
test('formatTime: 3661 seconds', () => assert(formatTime(3661) === '01:01:01'));
test('formatTime: 30000 seconds', () => assert(formatTime(30000) === '08:20:00'));

// Test escapeYaml
function escapeYaml(str) {
  return str.replace(/"/g, '\\"').replace(/\n/g, ' ');
}

test('escapeYaml: quotes', () => assert(escapeYaml('He said "hello"') === 'He said \\"hello\\"'));
test('escapeYaml: newlines', () => assert(escapeYaml('line1\nline2') === 'line1 line2'));

// Test sanitizeFilename
function sanitizeFilename(name) {
  return name.replace(/[^a-z0-9\s\-_]/gi, '').replace(/\s+/g, '-').replace(/^-+|-+$/g, '').substring(0, 80).toLowerCase();
}

test('sanitizeFilename: normal', () => assert(sanitizeFilename('Hello World') === 'hello-world'));
test('sanitizeFilename: special chars', () => assert(sanitizeFilename('Build & Sell (10+ Hour)') === 'build-sell-10-hour'));
test('sanitizeFilename: leading/trailing spaces', () => assert(sanitizeFilename('  Hello  ') === 'hello'));
test('sanitizeFilename: unicode', () => assert(sanitizeFilename('Ünïcödé Tëst') === 'ncd-tst'));

// Test decodeEntities
function decodeEntities(str) {
  return str
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&apos;/g, "'")
    .replace(/&#39;/g, "'")
    .replace(/&#x27;/g, "'")
    .replace(/&#(\d+);/g, (_, n) => String.fromCharCode(parseInt(n, 10)));
}

test('decodeEntities: amp', () => assert(decodeEntities('&amp;') === '&'));
test('decodeEntities: lt gt', () => assert(decodeEntities('&lt;b&gt;') === '<b>'));
test('decodeEntities: quot', () => assert(decodeEntities('&quot;hi&quot;') === '"hi"'));
test('decodeEntities: apos', () => assert(decodeEntities("don&apos;t") === "don't"));
test('decodeEntities: &#39;', () => assert(decodeEntities("it&#39;s") === "it's"));
test('decodeEntities: numeric', () => assert(decodeEntities('&#65;') === 'A'));

// Test XML parsing (srv3 format)
function parseSrv3(xml) {
  const results = [];
  const bodyMatch = xml.match(/<body>([\s\S]*?)<\/body>/);
  if (!bodyMatch) return results;
  const body = bodyMatch[1];
  const pRegex = /<p\s+t="(\d+)"[^>]*d="(\d+)"[^>]*>([\s\S]*?)<\/p>/g;
  let match;
  while ((match = pRegex.exec(body)) !== null) {
    const startMs = parseInt(match[1], 10);
    const text = match[3].replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
    const decoded = decodeEntities(text);
    if (decoded) results.push({ start: startMs / 1000, text: decoded });
  }
  return results;
}

const srv3Sample = `<?xml version="1.0"?><timedtext><body><p t="1000" d="2000" w="1">Hello world</p><p t="3000" d="2000" w="1">Second line</p></body></timedtext>`;
test('parseSrv3: basic', () => {
  const r = parseSrv3(srv3Sample);
  assert(r.length === 2);
  assert(r[0].start === 1);
  assert(r[0].text === 'Hello world');
  assert(r[1].start === 3);
});

const srv3Entities = `<?xml version="1.0"?><timedtext><body><p t="0" d="1000" w="1">don&apos;t &amp; won&apos;t</p></body></timedtext>`;
test('parseSrv3: entities', () => {
  const r = parseSrv3(srv3Entities);
  assert(r[0].text === "don't & won't", `Got: "${r[0].text}"`);
});

const srv3Nested = `<?xml version="1.0"?><timedtext><body><p t="5000" d="3000" w="1"><s>Hello</s> <s>world</s></p></body></timedtext>`;
test('parseSrv3: nested s tags', () => {
  const r = parseSrv3(srv3Nested);
  assert(r[0].text === 'Hello world');
});

// Test XML parsing (classic format)
function parseClassic(xml) {
  const results = [];
  const regex = /<text\s+start="([\d.]+)"(?:\s+dur="[\d.]+")?\s*>([\s\S]*?)<\/text>/g;
  let match;
  while ((match = regex.exec(xml)) !== null) {
    const start = parseFloat(match[1]);
    const rawText = match[2].replace(/<[^>]+>/g, '').replace(/\s+/g, ' ').trim();
    const decoded = decodeEntities(rawText);
    if (decoded) results.push({ start, text: decoded });
  }
  return results;
}

const classicSample = `<transcript><text start="0.5" dur="2.0">Hello there</text><text start="2.5" dur="1.5">General Kenobi</text></transcript>`;
test('parseClassic: basic', () => {
  const r = parseClassic(classicSample);
  assert(r.length === 2);
  assert(r[0].start === 0.5);
  assert(r[0].text === 'Hello there');
});

const classicEntities = `<transcript><text start="1.0" dur="2.0">it&apos;s &amp; that&apos;s</text></transcript>`;
test('parseClassic: entities', () => {
  const r = parseClassic(classicEntities);
  assert(r[0].text === "it's & that's", `Got: "${r[0].text}"`);
});

// ============================================================
// 9. MARKDOWN FRONTMATTER TESTS
// ============================================================
console.log('\n📝 MARKDOWN FRONTMATTER');

function generateMarkdownContent(meta, transcript) {
  const url = meta.url || '';
  const title = meta.title || 'Untitled';
  const author = meta.author || '';
  const published = meta.publishDate || '';
  const description = meta.description || '';
  const duration = meta.duration || '';
  const views = meta.viewCount || '';
  const lang = meta.language || 'en';

  let md = '---\n';
  md += `title: "${escapeYaml(title)}"\n`;
  if (author) md += `author: "${escapeYaml(author)}"\n`;
  md += `site: "YouTube"\n`;
  md += `domain: "youtube.com"\n`;
  md += `url: "${url}"\n`;
  if (published) md += `published: "${published}"\n`;
  if (duration) md += `duration: "${duration}"\n`;
  if (views) md += `views: "${views}"\n`;
  if (description) md += `description: "${escapeYaml(description.substring(0, 200))}"\n`;
  md += `language: "${lang}"\n`;
  md += `extracted: "2026-04-07T12:00:00.000Z"\n`;
  md += '---\n\n';
  md += `# ${title}\n\n`;
  transcript.forEach(item => {
    md += `**[${formatTime(item.start)}]** ${item.text}\n\n`;
  });
  return md;
}

const testMeta = {
  title: 'Build & Sell with Claude Code (10+ Hour Course)',
  author: 'Nate Herk | AI Automation',
  url: 'https://www.youtube.com/watch?v=mpALXah_PBg',
  publishDate: '2026-03-12T07:35:41-07:00',
  description: 'Full courses + unlimited support',
  duration: '10:23:45',
  viewCount: '150,000',
  language: 'en'
};

const testTranscript = [
  { start: 0, text: 'Welcome to the course' },
  { start: 5, text: 'Today we will learn about Claude Code' }
];

const md = generateMarkdownContent(testMeta, testTranscript);

test('MD has YAML frontmatter delimiters', () => {
  assert(md.startsWith('---\n'));
  assert(md.includes('\n---\n'));
});
test('MD has title', () => assert(md.includes('title: "Build & Sell with Claude Code (10+ Hour Course)"')));
test('MD has author', () => assert(md.includes('author: "Nate Herk | AI Automation"')));
test('MD has site', () => assert(md.includes('site: "YouTube"')));
test('MD has domain', () => assert(md.includes('domain: "youtube.com"')));
test('MD has url', () => assert(md.includes('url: "https://www.youtube.com/watch?v=mpALXah_PBg"')));
test('MD has published', () => assert(md.includes('published: "2026-03-12T07:35:41-07:00"')));
test('MD has duration', () => assert(md.includes('duration: "10:23:45"')));
test('MD has views', () => assert(md.includes('views: "150,000"')));
test('MD has description', () => assert(md.includes('description: "Full courses + unlimited support"')));
test('MD has language', () => assert(md.includes('language: "en"')));
test('MD has extracted timestamp', () => assert(md.includes('extracted:')));
test('MD has H1 title', () => assert(md.includes('# Build & Sell with Claude Code (10+ Hour Course)')));
test('MD has timestamped transcript', () => {
  assert(md.includes('**[00:00]** Welcome to the course'));
  assert(md.includes('**[00:05]** Today we will learn about Claude Code'));
});

// ============================================================
// 10. SKILL PROMPT QUALITY TESTS
// ============================================================
console.log('\n🛠️  SKILL PROMPT QUALITY');

test('Manus prompt instructs YAML frontmatter', () => {
  assert(bgJs.includes('Start with YAML frontmatter'));
});
test('Manus prompt requires name field', () => {
  assert(bgJs.includes('name: lowercase-hyphenated'));
});
test('Manus prompt requires description field', () => {
  assert(bgJs.includes('description: 1-2 sentences'));
});
test('Manus prompt focuses on procedural knowledge', () => {
  assert(bgJs.includes('PROCEDURAL knowledge'));
});
test('Manus prompt limits token usage', () => {
  assert(bgJs.includes('token cost') || bgJs.includes('token-efficient'));
});
test('Claude Code prompt requires invocation field', () => {
  assert(bgJs.includes('invocation: "user"'));
});
test('Claude Code prompt mentions string substitutions', () => {
  assert(bgJs.includes('{{cwd}}'));
  assert(bgJs.includes('{{os}}'));
});
test('Claude Code prompt references Claude Code tools', () => {
  assert(bgJs.includes('Read, Write, Edit, Bash'));
});
test('Both prompts say output ONLY SKILL.md', () => {
  const count = (bgJs.match(/Output ONLY the SKILL\.md/g) || []).length;
  assert(count >= 2, `Found ${count} occurrences, expected 2`);
});

// ============================================================
// SUMMARY
// ============================================================
console.log(`\n${'='.repeat(50)}`);
console.log(`RESULTS: ${passed} passed, ${failed} failed, ${skipped} skipped (${passed + failed + skipped} total)`);
console.log(`${'='.repeat(50)}`);

if (failed > 0) process.exit(1);
