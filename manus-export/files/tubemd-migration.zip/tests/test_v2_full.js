// TubeMD V2 - Comprehensive End-to-End Test Suite
// Tests: XML parsing, metadata extraction, Markdown generation, AI provider routing,
//        trial/monetization logic, popup-content communication, edge cases

let passed = 0, failed = 0, skipped = 0;

function assert(condition, name) {
  if (condition) { console.log(`  PASS: ${name}`); passed++; }
  else { console.log(`  FAIL: ${name}`); failed++; }
}

function section(name) { console.log(`\n=== ${name} ===`); }

// ============================================================
// 1. SRV3 XML PARSING
// ============================================================
section('SRV3 XML Parsing');

function parseWithRegex_srv3(xml) {
  const transcript = [];
  const pRegex = /<p\s+t="(\d+)"\s+d="(\d+)"[^>]*>([\s\S]*?)<\/p>/g;
  let match;
  while ((match = pRegex.exec(xml)) !== null) {
    const startMs = parseInt(match[1], 10);
    const durMs = parseInt(match[2], 10);
    let text = '';
    const sRegex = /<s[^>]*>([^<]*)<\/s>/g;
    let sMatch;
    while ((sMatch = sRegex.exec(match[3])) !== null) { text += sMatch[1]; }
    if (!text) text = match[3].replace(/<[^>]+>/g, '');
    text = decodeEntities(text).trim();
    if (text) transcript.push({ text, start: startMs / 1000, duration: durMs / 1000, end: (startMs + durMs) / 1000 });
  }
  return transcript;
}

const srv3Xml = `<?xml version="1.0" encoding="utf-8" ?>
<timedtext format="3">
<body>
<p t="0" d="5000"><s>Hello </s><s>world</s></p>
<p t="5000" d="3000"><s>This is </s><s>a test</s></p>
<p t="10000" d="4000"><s>With entities &amp;apos;quotes&amp;apos; &amp;amp; more</s></p>
<p t="15000" d="2000"></p>
<p t="20000" d="3000"><s>   </s></p>
<p t="25000" d="3500"><s>Final segment</s></p>
</body>
</timedtext>`;

const srv3Result = parseWithRegex_srv3(srv3Xml);
assert(srv3Result.length === 4, 'srv3: got 4 non-empty segments');
assert(srv3Result[0].text === 'Hello world', 'srv3: first text correct');
assert(srv3Result[0].start === 0, 'srv3: first starts at 0');
assert(srv3Result[0].end === 5, 'srv3: first ends at 5');
assert(srv3Result[1].text === 'This is a test', 'srv3: second text correct');
assert(srv3Result[1].start === 5, 'srv3: second starts at 5');
assert(srv3Result[2].text === "With entities 'quotes' & more", 'srv3: entities decoded');
assert(srv3Result[3].text === 'Final segment', 'srv3: skipped empty/whitespace segments');

// ============================================================
// 2. CLASSIC XML PARSING
// ============================================================
section('Classic XML Parsing');

function parseWithRegex_classic(xml) {
  const transcript = [];
  const textRegex = /<text\s+start="([^"]*)"\s+dur="([^"]*)"[^>]*>([\s\S]*?)<\/text>/g;
  let match;
  while ((match = textRegex.exec(xml)) !== null) {
    const start = parseFloat(match[1]);
    const dur = parseFloat(match[2] || '0');
    let text = match[3] || '';
    text = text.replace(/<[^>]+>/g, '').replace(/\n/g, ' ');
    text = decodeEntities(text).trim();
    if (text) transcript.push({ text, start, duration: dur, end: start + dur });
  }
  return transcript;
}

const classicXml = `<?xml version="1.0" encoding="utf-8" ?>
<transcript>
<text start="0.5" dur="2.1">Hello world</text>
<text start="2.6" dur="3.0">This has &amp;amp; entities &amp;lt;tag&amp;gt;</text>
<text start="5.6" dur="1.5">  </text>
<text start="7.1" dur="2.0">Last line</text>
</transcript>`;

const classicResult = parseWithRegex_classic(classicXml);
assert(classicResult.length === 3, 'classic: got 3 non-empty segments');
assert(classicResult[0].text === 'Hello world', 'classic: first text correct');
assert(classicResult[0].start === 0.5, 'classic: first starts at 0.5');
assert(classicResult[1].text === 'This has & entities <tag>', 'classic: entities decoded correctly');
assert(classicResult[2].text === 'Last line', 'classic: last text correct');

// ============================================================
// 3. YAML FRONTMATTER GENERATION
// ============================================================
section('YAML Frontmatter Generation');

function escapeYaml(str) {
  return str.replace(/"/g, '\\"').replace(/\n/g, ' ');
}

function formatTime(seconds) {
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = Math.floor(seconds % 60);
  if (h > 0) return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
  return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
}

function generateMarkdown(meta, transcript, selectedLang) {
  let md = '---\n';
  md += `title: "${escapeYaml(meta.title)}"\n`;
  if (meta.author) md += `author: "${escapeYaml(meta.author)}"\n`;
  md += `site: "YouTube"\n`;
  md += `domain: "youtube.com"\n`;
  md += `url: "${meta.url}"\n`;
  if (meta.publishDate) md += `published: "${meta.publishDate}"\n`;
  if (meta.duration) md += `duration: "${meta.duration}"\n`;
  if (meta.viewCount) md += `views: "${meta.viewCount}"\n`;
  if (meta.description) md += `description: "${escapeYaml(meta.description.substring(0, 200))}"\n`;
  md += `language: "${selectedLang || 'en'}"\n`;
  md += `extracted: "${new Date().toISOString()}"\n`;
  md += '---\n\n';
  if (meta.videoId) md += `![${escapeYaml(meta.title)}](https://www.youtube.com/watch?v=${meta.videoId})\n\n`;
  md += `# ${meta.title}\n\n`;
  transcript.forEach(item => {
    md += `**[${formatTime(item.start)}]** ${item.text}\n\n`;
  });
  return md;
}

const testMeta = {
  title: 'Build & Sell with Claude Code (10+ Hour Course)',
  author: 'Nate Herk | AI Automation',
  url: 'https://www.youtube.com/watch?v=mpALXah_PBg',
  publishDate: '2026-03-12T07:35:41-07:00',
  duration: '10h 23m 15s',
  viewCount: '1234567',
  description: 'Full courses + unlimited support: https://www.skool.com/ai-automation-society-plus/about',
  videoId: 'mpALXah_PBg',
  category: 'Education'
};

const testTranscript = [
  { text: 'Hello and welcome', start: 0, duration: 3, end: 3 },
  { text: 'Today we build with Claude', start: 3, duration: 4, end: 7 },
  { text: 'This is the final part', start: 3600, duration: 5, end: 3605 }
];

const md = generateMarkdown(testMeta, testTranscript, 'en');

assert(md.startsWith('---\n'), 'md: starts with YAML delimiter');
assert(md.includes('title: "Build & Sell with Claude Code (10+ Hour Course)"'), 'md: title present');
assert(md.includes('author: "Nate Herk | AI Automation"'), 'md: author present');
assert(md.includes('site: "YouTube"'), 'md: site present');
assert(md.includes('domain: "youtube.com"'), 'md: domain present');
assert(md.includes('url: "https://www.youtube.com/watch?v=mpALXah_PBg"'), 'md: url present');
assert(md.includes('published: "2026-03-12T07:35:41-07:00"'), 'md: published present');
assert(md.includes('duration: "10h 23m 15s"'), 'md: duration present');
assert(md.includes('views: "1234567"'), 'md: views present');
assert(md.includes('language: "en"'), 'md: language present');
assert(md.includes('extracted:'), 'md: extracted timestamp present');
assert(md.includes('# Build & Sell with Claude Code (10+ Hour Course)'), 'md: h1 title');
assert(md.includes('**[00:00]** Hello and welcome'), 'md: first timestamp');
assert(md.includes('**[00:03]** Today we build with Claude'), 'md: second timestamp');
assert(md.includes('**[01:00:00]** This is the final part'), 'md: hour timestamp format');
assert(md.includes('![Build'), 'md: video embed link present');

// ============================================================
// 4. ENTITY DECODING
// ============================================================
section('Entity Decoding');

function decodeEntities(text) {
  return text
    .replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&#x27;/g, "'")
    .replace(/&#x2F;/g, '/').replace(/&nbsp;/g, ' ');
}

assert(decodeEntities('&amp;') === '&', 'decode: &amp;');
assert(decodeEntities('&lt;') === '<', 'decode: &lt;');
assert(decodeEntities('&gt;') === '>', 'decode: &gt;');
assert(decodeEntities('&quot;') === '"', 'decode: &quot;');
assert(decodeEntities('&#39;') === "'", 'decode: &#39;');
assert(decodeEntities('&#x27;') === "'", 'decode: &#x27;');
assert(decodeEntities('&#x2F;') === '/', 'decode: &#x2F;');
assert(decodeEntities('&nbsp;') === ' ', 'decode: &nbsp;');
assert(decodeEntities('no entities here') === 'no entities here', 'decode: passthrough');
assert(decodeEntities('&amp;amp;') === '&amp;', 'decode: double-encoded &amp;amp;');

// ============================================================
// 5. FORMAT TIME
// ============================================================
section('Format Time');

assert(formatTime(0) === '00:00', 'time: 0');
assert(formatTime(1) === '00:01', 'time: 1');
assert(formatTime(59) === '00:59', 'time: 59');
assert(formatTime(60) === '01:00', 'time: 60');
assert(formatTime(61) === '01:01', 'time: 61');
assert(formatTime(599) === '09:59', 'time: 599');
assert(formatTime(600) === '10:00', 'time: 600');
assert(formatTime(3599) === '59:59', 'time: 3599');
assert(formatTime(3600) === '01:00:00', 'time: 3600 (1 hour)');
assert(formatTime(3661) === '01:01:01', 'time: 3661');
assert(formatTime(36000) === '10:00:00', 'time: 36000 (10 hours)');
assert(formatTime(0.7) === '00:00', 'time: 0.7 (floor)');
assert(formatTime(59.9) === '00:59', 'time: 59.9 (floor)');

// ============================================================
// 6. SANITIZE FILENAME
// ============================================================
section('Sanitize Filename');

function sanitizeFilename(name) {
  return name.replace(/[^a-z0-9\s\-_]/gi, '').replace(/\s+/g, '-').substring(0, 80).toLowerCase();
}

assert(sanitizeFilename('Hello World') === 'hello-world', 'filename: basic');
assert(sanitizeFilename('Build & Sell with Claude Code (10+ Hour Course)') === 'build-sell-with-claude-code-10-hour-course', 'filename: special chars stripped');
assert(sanitizeFilename('   spaces   everywhere   ') === 'spaces-everywhere', 'filename: multiple spaces');
assert(sanitizeFilename('') === '', 'filename: empty');
assert(sanitizeFilename('A'.repeat(200)).length <= 80, 'filename: truncates to 80');
assert(sanitizeFilename('file_name-test') === 'file_name-test', 'filename: preserves underscores and hyphens');
assert(sanitizeFilename('日本語タイトル') === '', 'filename: non-ascii stripped');

// ============================================================
// 7. ESCAPE YAML
// ============================================================
section('Escape YAML');

assert(escapeYaml('normal text') === 'normal text', 'yaml: passthrough');
assert(escapeYaml('text with "quotes"') === 'text with \\"quotes\\"', 'yaml: quotes escaped');
assert(escapeYaml('line1\nline2') === 'line1 line2', 'yaml: newlines replaced');
assert(escapeYaml('"start" and "end"') === '\\"start\\" and \\"end\\"', 'yaml: multiple quotes');
assert(escapeYaml('') === '', 'yaml: empty string');

// ============================================================
// 8. AI PROVIDER ROUTING (simulate background.js logic)
// ============================================================
section('AI Provider Routing');

function buildAiRequest(provider, apiKey, text) {
  const prompt = `Summarize this YouTube transcript:\n\n${text}`;
  switch (provider) {
    case 'gemini':
      return {
        url: `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${apiKey}`,
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: { contents: [{ parts: [{ text: prompt }] }] }
      };
    case 'openai':
      return {
        url: 'https://api.openai.com/v1/chat/completions',
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${apiKey}` },
        body: { model: 'gpt-4o-mini', messages: [{ role: 'user', content: prompt }] }
      };
    case 'claude':
      return {
        url: 'https://api.anthropic.com/v1/messages',
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-api-key': apiKey, 'anthropic-version': '2023-06-01' },
        body: { model: 'claude-sonnet-4-20250514', max_tokens: 4096, messages: [{ role: 'user', content: prompt }] }
      };
    default:
      throw new Error(`Unknown provider: ${provider}`);
  }
}

const geminiReq = buildAiRequest('gemini', 'test-key-123', 'Hello world');
assert(geminiReq.url.includes('generativelanguage.googleapis.com'), 'ai: gemini url correct');
assert(geminiReq.url.includes('test-key-123'), 'ai: gemini key in url');
assert(geminiReq.body.contents[0].parts[0].text.includes('Hello world'), 'ai: gemini body has text');

const openaiReq = buildAiRequest('openai', 'sk-test', 'Hello world');
assert(openaiReq.url.includes('api.openai.com'), 'ai: openai url correct');
assert(openaiReq.headers.Authorization === 'Bearer sk-test', 'ai: openai auth header');
assert(openaiReq.body.model === 'gpt-4o-mini', 'ai: openai model correct');

const claudeReq = buildAiRequest('claude', 'sk-ant-test', 'Hello world');
assert(claudeReq.url.includes('api.anthropic.com'), 'ai: claude url correct');
assert(claudeReq.headers['x-api-key'] === 'sk-ant-test', 'ai: claude api key header');
assert(claudeReq.headers['anthropic-version'] === '2023-06-01', 'ai: claude version header');
assert(claudeReq.body.model.includes('claude'), 'ai: claude model correct');

try { buildAiRequest('unknown', 'key', 'text'); assert(false, 'ai: unknown provider throws'); }
catch (e) { assert(e.message.includes('Unknown provider'), 'ai: unknown provider throws'); }

// ============================================================
// 9. TRIAL/MONETIZATION LOGIC
// ============================================================
section('Trial/Monetization Logic');

function checkTrialStatus(trialStartDate, isPro) {
  if (isPro) return { active: true, reason: 'pro' };
  if (!trialStartDate) return { active: true, reason: 'new_user', daysLeft: 14 };
  const start = new Date(trialStartDate);
  const now = new Date();
  const daysPassed = Math.floor((now - start) / (1000 * 60 * 60 * 24));
  const daysLeft = 14 - daysPassed;
  if (daysLeft > 0) return { active: true, reason: 'trial', daysLeft };
  return { active: false, reason: 'expired', daysLeft: 0 };
}

const proUser = checkTrialStatus('2025-01-01', true);
assert(proUser.active === true, 'trial: pro user always active');
assert(proUser.reason === 'pro', 'trial: pro reason');

const newUser = checkTrialStatus(null, false);
assert(newUser.active === true, 'trial: new user active');
assert(newUser.reason === 'new_user', 'trial: new user reason');
assert(newUser.daysLeft === 14, 'trial: new user 14 days');

const recentTrial = checkTrialStatus(new Date(Date.now() - 5 * 86400000).toISOString(), false);
assert(recentTrial.active === true, 'trial: 5 days in still active');
assert(recentTrial.daysLeft > 0, 'trial: days left > 0');

const expiredTrial = checkTrialStatus(new Date(Date.now() - 30 * 86400000).toISOString(), false);
assert(expiredTrial.active === false, 'trial: 30 days expired');
assert(expiredTrial.reason === 'expired', 'trial: expired reason');

const justExpired = checkTrialStatus(new Date(Date.now() - 15 * 86400000).toISOString(), false);
assert(justExpired.active === false, 'trial: 15 days expired');

const dayBefore = checkTrialStatus(new Date(Date.now() - 13 * 86400000).toISOString(), false);
assert(dayBefore.active === true, 'trial: 13 days still active');

// ============================================================
// 10. MARKDOWN vs TEXT FORMAT
// ============================================================
section('Markdown vs Text Format');

function generatePlainText(meta, transcript) {
  let txt = `${meta.title}\n`;
  txt += `By: ${meta.author}\n`;
  txt += `URL: ${meta.url}\n`;
  txt += `Published: ${meta.publishDate}\n\n`;
  transcript.forEach(item => {
    txt += `[${formatTime(item.start)}] ${item.text}\n`;
  });
  return txt;
}

const plainText = generatePlainText(testMeta, testTranscript);
assert(!plainText.includes('---'), 'text: no YAML frontmatter');
assert(!plainText.includes('**'), 'text: no bold markdown');
assert(plainText.includes('[00:00] Hello and welcome'), 'text: timestamps present');
assert(plainText.includes('Build & Sell'), 'text: title present');

// ============================================================
// 11. LIVE INNERTUBE API TEST
// ============================================================
section('Live InnerTube API Test');

async function testInnerTube() {
  const videoId = 'mpALXah_PBg';
  const body = {
    context: { client: { clientName: 'ANDROID', clientVersion: '20.10.38' } },
    videoId
  };
  const apiKey = 'AIzaSyAO_FJ2SlqU8Q4STEHLGCilw_Y9_11qcW8';
  try {
    const resp = await fetch(`https://www.youtube.com/youtubei/v1/player?key=${apiKey}&prettyPrint=false`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'User-Agent': 'com.google.android.youtube/20.10.38 (Linux; U; Android 14)'
      },
      body: JSON.stringify(body)
    });
    const data = await resp.json();
    const status = data?.playabilityStatus?.status;
    console.log(`  InnerTube status: ${status}`);
    
    if (status === 'OK') {
      const tracks = data?.captions?.playerCaptionsTracklistRenderer?.captionTracks;
      assert(Array.isArray(tracks), 'innertube: captionTracks is array');
      assert(tracks.length > 0, 'innertube: has caption tracks');
      
      // Test XML fetch
      const xmlResp = await fetch(tracks[0].baseUrl);
      const xml = await xmlResp.text();
      assert(xml.length > 100, 'innertube: XML response has content');
      
      // Test parsing
      let parsed = parseWithRegex_srv3(xml);
      if (parsed.length === 0) parsed = parseWithRegex_classic(xml);
      assert(parsed.length > 0, `innertube: parsed ${parsed.length} segments`);
      assert(parsed[0].text.length > 0, 'innertube: first segment has text');
      assert(typeof parsed[0].start === 'number', 'innertube: start is number');
      
      // Test full Markdown generation with real data
      const realMd = generateMarkdown({
        title: 'Test Video', author: 'Test Author',
        url: `https://www.youtube.com/watch?v=${videoId}`,
        publishDate: '2026-03-12', duration: '10h', viewCount: '1000',
        description: 'Test', videoId
      }, parsed.slice(0, 5), tracks[0].languageCode);
      assert(realMd.includes('---\n'), 'innertube: real MD has frontmatter');
      assert(realMd.includes('# Test Video'), 'innertube: real MD has title');
      
      console.log(`  Live test: ${parsed.length} segments parsed, Markdown generated successfully`);
    } else {
      console.log(`  SKIP: InnerTube returned ${status} (expected in sandbox, works in browser with cookies)`);
      skipped += 6;
    }
  } catch (e) {
    console.log(`  SKIP: Network error: ${e.message}`);
    skipped += 6;
  }
}

// ============================================================
// 12. EDGE CASES
// ============================================================
section('Edge Cases');

// Empty transcript
const emptyMd = generateMarkdown(testMeta, [], 'en');
assert(emptyMd.includes('---\n'), 'edge: empty transcript still has frontmatter');
assert(emptyMd.includes('# Build & Sell'), 'edge: empty transcript still has title');
assert(!emptyMd.includes('**['), 'edge: no timestamp entries');

// Title with special characters
const specialMeta = { ...testMeta, title: 'Title with "quotes" and <html> & stuff' };
const specialMd = generateMarkdown(specialMeta, testTranscript, 'en');
assert(specialMd.includes('title: "Title with \\"quotes\\" and <html> & stuff"'), 'edge: special chars in YAML');

// Very long transcript
const longTranscript = Array.from({ length: 10000 }, (_, i) => ({
  text: `Segment ${i} with some text content here`, start: i * 3, duration: 3, end: (i + 1) * 3
}));
const longMd = generateMarkdown(testMeta, longTranscript, 'en');
assert(longMd.split('\n').length > 10000, 'edge: long transcript generates');
assert(longMd.includes('**[08:20:00]**'), 'edge: long transcript has correct timestamps');

// Unicode content
const unicodeTranscript = [
  { text: '日本語テスト', start: 0, duration: 3, end: 3 },
  { text: 'Ñoño español', start: 3, duration: 3, end: 6 },
  { text: '中文测试', start: 6, duration: 3, end: 9 }
];
const unicodeMd = generateMarkdown(testMeta, unicodeTranscript, 'ja');
assert(unicodeMd.includes('日本語テスト'), 'edge: Japanese preserved');
assert(unicodeMd.includes('Ñoño español'), 'edge: Spanish preserved');
assert(unicodeMd.includes('language: "ja"'), 'edge: language set to ja');

// ============================================================
// RUN ASYNC TESTS
// ============================================================
(async () => {
  await testInnerTube();
  
  console.log('\n' + '='.repeat(50));
  console.log(`RESULTS: ${passed} passed, ${failed} failed, ${skipped} skipped, ${passed + failed + skipped} total`);
  console.log('='.repeat(50));
  
  if (failed > 0) process.exit(1);
})();
