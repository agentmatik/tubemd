# UI Analysis from Screenshots

## Extension Panel Layout
- Appears as a sidebar panel on the RIGHT side of the YouTube page
- Header: "YouTube To Text" with eye icon (toggle visibility) and user icon
- Three tabs: "Transcription" | "Pro Transcription" | "Summary"
- Below tabs: Language selector (globe icon + "EN"), Copy button, More options (three dots)

## Transcription Tab (Right panel in screenshot)
- Shows timestamped transcript
- Format: "00:00  [transcript text]"
- Timestamps are clickable (blue/colored)
- Text is grouped in paragraphs by timestamp
- Clean, readable layout

## Summary Tab (Left panel in screenshot - dark mode)
- Shows "Summary" heading with AI-generated summary paragraph
- Shows "KeyPoints" section with emoji bullet points
- Dark background with white text

## Design Elements
- Clean, modern design
- Supports dark mode
- Rounded tab buttons
- Sidebar width approximately 350-400px
- Scrollable content area

## Features to Replicate
1. Sidebar panel injected into YouTube page
2. Three tabs: Transcription, Pro Transcription, Summary
3. Timestamp-linked transcript (click to jump)
4. AI Summary with key points
5. Copy to clipboard
6. Download as text
7. Language selection
8. Dark mode support
9. Search within transcript
