# Superpowers Assessment Notes

## What it is
- An "agentic skills framework & software development methodology" for coding agents
- 137k stars, very popular
- Provides composable "skills" and initial instructions for coding agents
- Supported platforms: Claude Code, Cursor, Codex, OpenCode, GitHub Copilot CLI, Gemini CLI

## What it does
- Workflow: brainstorming → design → implementation plan → subagent-driven development → TDD → code review → finish
- Skills include: TDD, systematic debugging, brainstorming, writing plans, executing plans, parallel agents, code review, git worktrees
- Emphasizes RED-GREEN-REFACTOR TDD, YAGNI, DRY
- Designed for coding agents (Claude Code, Cursor, Codex, etc.)

## Key question: Is it useful for THIS task?
- This is a Chrome extension development task running in Manus sandbox
- Superpowers is designed for: Claude Code, Cursor, Codex, OpenCode, Gemini CLI, Copilot CLI
- Manus is NONE of these platforms
- Superpowers requires plugin installation via platform-specific commands (/plugin install, /add-plugin, etc.)
- Manus has its own agent loop, tool system, and planning framework
- Superpowers skills are markdown files that instruct coding agents - they're prompts/instructions, not executable tools
- Installing Superpowers in this sandbox would have no effect - it can't hook into Manus's agent loop

## Verdict: NOT useful for this context
- Wrong platform (Manus, not Claude Code/Cursor/etc.)
- Cannot integrate with Manus's tool system
- The skills are agent instructions, not standalone tools
- Would just be dead files in the sandbox
