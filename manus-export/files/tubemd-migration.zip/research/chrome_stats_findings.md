# Chrome-Stats Findings for YouTube To Text

## Key Technical Details
- Developer: denbobscws
- Created: 2023-11-07
- Manifest V3
- Size: 698KB
- Users: 200,000
- Rating: 4.61 (1,226 ratings)

## Permissions Required
- identity
- storage
- scripting
- Host permissions: https://*/*
- Content scripts matches: www.youtube.com

## Important Discovery from Screenshots
- The promotional screenshots show: "Convert YouTube Video to Text - Powered by ChatGPT"
- "Supercharge YouTube: The Future is Here!"
- Tabs visible: "Transcription", "Pre Transcription", "Summary"
- This means it likely uses ChatGPT/AI for summarization features, not just raw transcript extraction

## Permission History
- 2025-08-29: Added host permissions https://*/* and scripting permission (v2.10.1 → v2.11.0)
- 2024-06-21: Added identity and storage permissions (v1.6.0 → v2.0.1)

## Risk Assessment
- Moderate risk impact (requires access to all websites)
- Moderate risk likelihood
- Critical: "Allows access to all websites, posing a significant security risk"

## Developer Website
- https://youtube-to-text.app

## Key Insight
The extension appears to have TWO layers:
1. Basic transcript extraction (free, uses YouTube's built-in captions)
2. AI-powered features like summarization (likely "Powered by ChatGPT" - may have limits or costs)
