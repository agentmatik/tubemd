# V2 Research Findings

## Payment Gateway Recommendation: ExtensionPay
- Built specifically for Chrome extensions
- Uses Stripe under the hood
- Supports one-time payments AND subscriptions
- 5% fee on top of Stripe's standard fees (2.9% + $0.30)
- No upfront costs, no monthly fees
- Simple integration: npm install extpay, ~10 lines of code
- Handles user management, paid status checking, login/reactivation
- Over $500K earned by extension creators
- Works with Manifest V3 service workers
- Open source JS library

## Alternative: LemonSqueezy
- Acts as Merchant of Record (handles taxes)
- Higher fees (~5-8% + payment processing)
- More complex integration for Chrome extensions
- Better for SaaS, not specifically designed for extensions

## Verdict: ExtensionPay is the clear winner for Chrome extensions

## Extension Naming - SEO Research
Existing names taken:
- "YouTube To Text" (the original)
- "YouTube Transcript" 
- "YT Transcript Downloader"
- "Export YouTube Clips"
- "YouTube AI Math Transcriber"

Keywords with search volume: youtube transcript, youtube to text, youtube markdown, youtube caption
Gap in market: No extension specifically branded for "YouTube to Markdown" or "YT MD"

Name candidates:
1. "TubeScript MD" - catchy, includes MD for markdown
2. "YT Transcript MD" - direct, SEO-friendly
3. "ClipScript - YouTube to Markdown" - unique brand + SEO subtitle
4. "VidText MD - YouTube Transcript to Markdown" - descriptive
5. "TubeMD - YouTube to Markdown Transcript" - short, memorable

## Defuddle Architecture
- Open source library by kepano (Obsidian creator)
- Core: defuddle npm package extracts main content from any page
- Clip extension: popup-based UI (not sidebar)
- Outputs: Markdown with YAML frontmatter, plain text, HTML
- Sync destinations: Obsidian, flomo, Notion, GitHub Issues
- All local-first, no server needed for extraction
- Settings page for configuring sync destinations

## Languages from Original Extension
English, Español, 日本語, Português, Русский, हिन्दी, 한국인, Italiano, عربي, 简体中文, Deutsch, Français, Polski, Bahasa Indonesia, ภาษาไทย, Nederlands, Tiếng Việt, Türkiye, Čeština, فارسی

## Pricing Strategy
Original: $99 lifetime, $3.99/mo yearly, $8.99/mo monthly
User wants: ~half, lifetime max $49

Recommended pricing:
- Lifetime: $49 (user's preference)
- Yearly: $1.99/mo billed annually ($23.88/year)
- Monthly: $4.99/mo
- Free tier: 10 transcriptions, then paywall
