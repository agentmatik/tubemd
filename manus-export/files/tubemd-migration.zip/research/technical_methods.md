# Technical Methods for YouTube Transcript Extraction

## Method 1: YouTube Innertube API (JavaScript/Chrome Extension approach)
- YouTube's internal API used by web, mobile, and embedded clients
- Not officially documented but accessible by observing network traffic
- Steps: Fetch INNERTUBE_API_KEY from video page HTML → Call player API (impersonate Android client) → Extract caption track URL → Fetch and parse XML captions
- Returns: caption text, startTime, endTime
- No API key required, no headless browser needed
- Most reliable current method (as of 2025)

## Method 2: youtube-transcript-api (Python library)
- GitHub: jdepoix/youtube-transcript-api - 7.2k stars, MIT license
- pip install youtube-transcript-api
- Works for manually created AND auto-generated subtitles
- No API key needed, no headless browser
- Supports: listing available transcripts, fetching specific languages, translating transcripts
- Returns: FetchedTranscript with text, start time, duration
- Has CLI interface too
- Known issue: IP bans from cloud providers (YouTube blocks cloud IPs)

## Method 3: YouTube Data API v3 (Official)
- Official Google API for captions
- Requires API key / OAuth
- Has quota limits
- More complex setup

## Method 4: timedtext endpoint
- Direct URL: youtube.com/api/timedtext?v=...
- Less reliable, may break with YouTube updates
- Some recent changes broke the &pot parameter

## Open Source Chrome Extensions Already Exist:
1. shtayeb/tiny-yt-transcript-extractor - MV3, content.js + background.js, 100% JavaScript
   - Adds transcript button to YouTube UI
   - Copy to clipboard or download as .txt
   - Works with YouTube's built-in transcript system
   - Only 3 files: manifest.json, content.js, background.js
   
2. helioLJ/youtube-transcript-copier - Adds "Copy Transcript" button

3. andresz74/youtube-transcript-extension - Extract transcript of any YouTube video

## Key Insight
The "YouTube to Text" extension (698KB) claims to operate locally in browser. The core functionality is simply:
1. Detect when user is on a YouTube video page
2. Access YouTube's built-in transcript/caption data (via page DOM or Innertube API)
3. Format and display the transcript with timestamps
4. Allow copy/download

This is fundamentally simple - the transcript data is already available from YouTube.
