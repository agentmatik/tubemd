# Developer Website Findings (youtube-to-text.app)

## Key Features Confirmed
1. Transcript extraction (video to text)
2. AI Summarization powered by ChatGPT (no need for own ChatGPT account)
3. Dark mode
4. Multi-language support
5. No account needed, no credit card needed

## Business Entity
- Developer: ИП Зуев И.В. (Russian individual entrepreneur)
- INN: 360408359441
- Has: Privacy Notice, Terms of Service, Refund Policy, Договор оферты (Offer agreement)

## Important: Refund Policy exists
The existence of a Refund Policy suggests there IS a paid component, even though the extension claims to be free. This likely means:
- Basic transcript extraction is free
- AI summarization (ChatGPT-powered) may have usage limits or a premium tier

## Two Core Components to Clone
1. **Transcript Extraction** (easy) - Just pulls YouTube's existing caption data
2. **AI Summarization** (requires API costs) - Uses ChatGPT to summarize transcripts
