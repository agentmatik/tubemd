# Defuddle Library Findings

Defuddle extracts: title, author, site, domain, description, published, language, image, favicon, metaTags, schemaOrgData.

For YouTube, it auto-generates an embed iframe and uses the og:description.

Key insight: We don't actually need defuddle library in our extension. We can extract the same metadata directly from YouTube's page since we're already parsing ytInitialPlayerResponse. We just need to format it as YAML frontmatter in the markdown output.

Our metadata sources from YouTube page:
- title: from ytInitialPlayerResponse.videoDetails.title
- author: from ytInitialPlayerResponse.videoDetails.author
- site: "YouTube" (hardcoded)
- domain: "youtube.com" (hardcoded)
- url: current page URL
- published: from ytInitialPlayerResponse.microformat.playerMicroformatRenderer.publishDate
- description: from ytInitialPlayerResponse.videoDetails.shortDescription
- duration: from ytInitialPlayerResponse.videoDetails.lengthSeconds
- views: from ytInitialPlayerResponse.videoDetails.viewCount
