# Key Findings from Kakulukian/youtube-transcript Library

## Critical Discovery: ANDROID Client Works!
The library uses **ANDROID client** for InnerTube API, NOT WEB client:
- clientName: 'ANDROID'
- clientVersion: '20.10.38'
- User-Agent: `com.google.android.youtube/20.10.38 (Linux; U; Android 14)`

This is the key difference! The ANDROID client often bypasses LOGIN_REQUIRED restrictions.

## Two-Method Approach:
1. **InnerTube API (ANDROID client)** - tried first
2. **HTML scraping** - fallback, parses `ytInitialPlayerResponse` from page

## parseInlineJson:
Uses `var ${globalName} = ` as start token, then counts braces.
Note: does NOT handle strings with braces inside them (simpler but may fail on edge cases).

## XML Parsing:
Supports TWO formats:
1. **srv3 format**: `<p t="ms" d="ms"><s>word</s>...</p>` (newer)
2. **Classic format**: `<text start="sec" dur="sec">content</text>` (older)

## For our Chrome extension content script:
- Should try ANDROID InnerTube first (from content script, with cookies)
- Fall back to page HTML extraction
- Support both XML formats
- The content script fetch() carries cookies automatically
