# V2 Requirements - Gathered from User Screenshots & Attachments

## Original Extension UI (Screenshots)
- Header: "YouTube To Text" with language flag icon, eye icon, user icon
- Tabs: Transcription | Pro Transcription | Summary
- Big red "GET TRANSCRIPTION" button
- "Contact Us" link below
- Language dropdown: English, Español, 日本語, Português, Русский, हिन्दी, 한국인, Italiano, عربي, 简体中文, Deutsch, Français, Polski, Bahasa Indonesia, ภาษาไทย, Nederlands, Tiếng Việt, Türkiye, Čeština, فارسی

## Defuddle Clip UI (Popup Screenshot)
- Header: "DEFUDDLE CLIP" label
- Large title: "Build & Sell with Claude Code (10+ Hour Course)"
- Subtitle: "YOUTUBE" / "Nate Herk | AI Automation / Mar 12, 2026"
- URL display
- REFRESH and OPTIONS buttons
- Status: "✓ EXTRACTED."
- Format tabs: MARKDOWN | TEXT | HTML (with icons)
- Content area showing markdown with frontmatter
- Bottom: "SET UP OBSIDIAN" and "SET UP FLOMO" buttons

## Defuddle Settings (Screenshots)
- Sync settings page with connections:
  1. Obsidian vault: Vault Name + Folder
  2. flomo webhook: Webhook URL + Default Tags
  3. Notion destination: Integration Token + Parent Page URL/ID
  4. GitHub issues: Personal Access Token + Repository + Labels
- Each has REMOVE and SAVE SETTINGS buttons
- Right side: Setup instructions for each
- Privacy note: "Tokens stay in your local Chrome storage"

## Defuddle Markdown Output Format
```
---
title: "Build & Sell with Claude Code (10+ Hour Course)"
author: "Nate Herk | AI Automation"
site: "YouTube"
domain: "youtube.com"
url: "https://www.youtube.com/watch?v=mpALXah_PBg&t=2s"
published: "2026-03-12T07:35:41-07:00"
description: "Full courses + unlimited support..."
---

![](https://www.youtube.com/watch?v=mpALXah_PBg)
```

## User's Custom Icon
- 3D style icon: Red play button with dark CC badge
- File: closed-caption-video-3d-icon-png-download-10544950.webp

## Pricing (Original Extension)
- Lifetime: $99 (marked "HIT 🔥")
- Yearly: $3.99/month (billed annually, "55% OFF")
- Monthly: $8.99/month
- User wants: ~half price, lifetime max $49

## Contact Email
- hello@agentmatik.ai
