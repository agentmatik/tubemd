# YouTube To Text Extension - Key Details

- **Extension ID**: apnedodbofogffiagpekmbeflilkcbgf
- **Users**: 200,000
- **Version**: 2.14.3
- **Size**: 698KiB
- **Updated**: April 5, 2026
- **Category**: Workflow & Planning
- **Price**: Free (claims to be free Chrome extension)

## Core Features
1. Transcribe YouTube videos to text
2. Search through textual content
3. Multiple language support (captions + auto-generated subtitles)
4. Save transcriptions, create playlists
5. Closed captions for accessibility
6. Time-coded transcripts
7. No ads, privacy-focused
8. Claims to operate locally within browser

## Key Claims
- "Extension operates locally within your browser"
- "Does not collect or store any user data"
- "No specific limitations on length or number of videos"
- Supports multiple languages
- Free to use

## Privacy
- Not selling data to third parties
- Not using data for unrelated purposes
