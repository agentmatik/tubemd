// YouTube To Text - Content Script
// Injects a panel into YouTube's secondary column (above recommendations)
// Transcript extraction happens HERE (in page context) so we have the user's cookies/auth

(function() {
  'use strict';

  // Prevent double injection
  if (document.getElementById('ytt-panel')) return;

  let currentVideoId = null;
  let transcriptData = null;
  let currentLang = '';
  let panelVisible = true;
  let searchQuery = '';

  // ============================================================
  // TRANSCRIPT EXTRACTION (runs in page context with user's cookies)
  // ============================================================

  /**
   * Extract caption tracks from the page's embedded player response.
   * YouTube embeds ytInitialPlayerResponse in the page HTML which contains
   * caption metadata. Since we're in the content script, we can also
   * access it via the page's JS context.
   */
  function getCaptionTracksFromPage() {
    // Method 1: Try to get from page scripts (most reliable)
    const scripts = document.querySelectorAll('script');
    for (const script of scripts) {
      const text = script.textContent;
      if (!text) continue;

      // Look for ytInitialPlayerResponse with captions
      const match = text.match(/ytInitialPlayerResponse\s*=\s*/);
      if (match) {
        const startIdx = match.index + match[0].length;
        try {
          const playerResponse = extractJsonObject(text, startIdx);
          const captions = playerResponse?.captions?.playerCaptionsTracklistRenderer;
          if (captions && captions.captionTracks && captions.captionTracks.length > 0) {
            return { captions, title: playerResponse?.videoDetails?.title || '' };
          }
        } catch (e) {
          // continue to next method
        }
      }
    }

    // Method 2: Search for captionTracks directly in any script
    for (const script of scripts) {
      const text = script.textContent;
      if (!text || !text.includes('captionTracks')) continue;

      const tracksMatch = text.match(/"captionTracks"\s*:\s*(\[.*?\])\s*[,}]/s);
      if (tracksMatch) {
        try {
          const tracks = JSON.parse(tracksMatch[1]);
          if (tracks.length > 0) {
            // Also try to get title
            const titleMatch = text.match(/"title"\s*:\s*"((?:[^"\\]|\\.)*)"/);
            return {
              captions: { captionTracks: tracks },
              title: titleMatch ? JSON.parse('"' + titleMatch[1] + '"') : ''
            };
          }
        } catch (e) {
          // continue
        }
      }
    }

    return null;
  }

  /**
   * Fetch transcript using YouTube's InnerTube API from the page context.
   * Being in the content script means our fetch() carries the user's YouTube cookies,
   * so we don't get "LOGIN_REQUIRED" errors like the background service worker does.
   */
  async function fetchTranscriptFromInnerTube(videoId) {
    // Get the page's innertube API key and client info
    let apiKey = '';
    let clientVersion = '';

    const scripts = document.querySelectorAll('script');
    for (const script of scripts) {
      const text = script.textContent;
      if (!text) continue;
      if (!apiKey) {
        const keyMatch = text.match(/"INNERTUBE_API_KEY"\s*:\s*"([^"]+)"/);
        if (keyMatch) apiKey = keyMatch[1];
      }
      if (!clientVersion) {
        const verMatch = text.match(/"INNERTUBE_CLIENT_VERSION"\s*:\s*"([^"]+)"/);
        if (verMatch) clientVersion = verMatch[1];
      }
      if (apiKey && clientVersion) break;
    }

    if (!apiKey) apiKey = 'AIzaSyAO_FJ2SlqU8Q4STEHLGCilw_Y9_11qcW8'; // fallback public key
    if (!clientVersion) clientVersion = '2.20240101.00.00';

    const response = await fetch(`https://www.youtube.com/youtubei/v1/player?key=${apiKey}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        context: {
          client: {
            hl: document.documentElement.lang || 'en',
            gl: 'US',
            clientName: 'WEB',
            clientVersion: clientVersion
          }
        },
        videoId: videoId
      })
    });

    const data = await response.json();
    const captions = data?.captions?.playerCaptionsTracklistRenderer;
    const title = data?.videoDetails?.title || '';

    if (captions && captions.captionTracks && captions.captionTracks.length > 0) {
      return { captions, title };
    }

    return null;
  }

  /**
   * Fetch the actual transcript XML for a given caption track URL.
   * Done from page context so cookies are included.
   */
  async function fetchTranscriptXml(baseUrl) {
    const response = await fetch(baseUrl);
    if (!response.ok) throw new Error(`Failed to fetch transcript: ${response.status}`);
    return await response.text();
  }

  /**
   * Parse transcript XML into structured data.
   * Uses DOMParser which IS available in the content script (page context).
   */
  function parseTranscriptXml(xml) {
    const parser = new DOMParser();
    const doc = parser.parseFromString(xml, 'text/xml');
    const textElements = doc.querySelectorAll('text');

    const transcript = [];
    textElements.forEach(el => {
      const start = parseFloat(el.getAttribute('start'));
      const duration = parseFloat(el.getAttribute('dur') || '0');
      let text = el.textContent || '';
      // Clean up the text
      text = text.replace(/\n/g, ' ').trim();

      if (text) {
        transcript.push({
          text,
          start,
          duration,
          end: start + duration
        });
      }
    });

    return transcript;
  }

  /**
   * Main transcript loading function.
   * Tries multiple methods to get captions, then fetches and parses the XML.
   */
  async function fetchTranscriptData(videoId, lang) {
    // Step 1: Try to get caption tracks from the page's embedded data
    let result = getCaptionTracksFromPage();

    // Step 2: If not found in page, try InnerTube API (with page cookies)
    if (!result) {
      result = await fetchTranscriptFromInnerTube(videoId);
    }

    if (!result || !result.captions || !result.captions.captionTracks || result.captions.captionTracks.length === 0) {
      throw new Error('No captions available for this video. The video may not have subtitles.');
    }

    const tracks = result.captions.captionTracks;

    // Build available languages list
    const availableLanguages = tracks.map(track => ({
      code: track.languageCode,
      name: track.name?.simpleText || track.name?.runs?.[0]?.text || track.languageCode,
      isGenerated: track.kind === 'asr',
      baseUrl: track.baseUrl
    }));

    // Find the requested language track, fallback to first available
    let selectedTrack = tracks.find(t => t.languageCode === lang);
    if (!selectedTrack) {
      selectedTrack = tracks[0];
    }

    // Step 3: Fetch the transcript XML
    const xml = await fetchTranscriptXml(selectedTrack.baseUrl);

    // Step 4: Parse the XML
    const transcript = parseTranscriptXml(xml);

    if (transcript.length === 0) {
      throw new Error('Transcript is empty. The captions may not contain any text.');
    }

    // Get video title from page if not in player response
    let videoTitle = result.title;
    if (!videoTitle) {
      const titleEl = document.querySelector('h1.ytd-watch-metadata yt-formatted-string, h1.title');
      videoTitle = titleEl?.textContent?.trim() || document.title.replace(' - YouTube', '').trim();
    }

    return {
      transcript,
      languages: availableLanguages,
      selectedLanguage: selectedTrack.languageCode,
      videoTitle
    };
  }

  // Helper: extract a JSON object starting at a given index in a string
  function extractJsonObject(str, startIdx) {
    let depth = 0;
    let inString = false;
    let escape = false;
    let start = -1;

    for (let i = startIdx; i < str.length && i < startIdx + 1000000; i++) {
      const ch = str[i];

      if (escape) {
        escape = false;
        continue;
      }

      if (ch === '\\' && inString) {
        escape = true;
        continue;
      }

      if (ch === '"') {
        inString = !inString;
        continue;
      }

      if (inString) continue;

      if (ch === '{') {
        if (depth === 0) start = i;
        depth++;
      } else if (ch === '}') {
        depth--;
        if (depth === 0) {
          return JSON.parse(str.substring(start, i + 1));
        }
      }
    }

    throw new Error('Could not extract JSON object');
  }

  // ============================================================
  // FIND YOUTUBE'S SECONDARY COLUMN & INJECT
  // ============================================================
  function findSecondaryColumn() {
    return document.querySelector('#secondary-inner') ||
           document.querySelector('#secondary') ||
           document.querySelector('ytd-watch-flexy #secondary');
  }

  function injectPanel() {
    const secondary = findSecondaryColumn();
    if (!secondary) {
      setTimeout(injectPanel, 500);
      return;
    }

    if (document.getElementById('ytt-panel')) return;

    const panel = createPanel();
    secondary.insertBefore(panel, secondary.firstChild);

    setupEventListeners();
    detectVideoChange();
  }

  // ============================================================
  // PANEL HTML
  // ============================================================
  function createPanel() {
    const panel = document.createElement('div');
    panel.id = 'ytt-panel';
    panel.innerHTML = `
      <!-- Header -->
      <div class="ytt-header">
        <div class="ytt-logo">
          <span class="ytt-logo-text">YouTube To Text</span>
        </div>
        <div class="ytt-header-actions">
          <button id="ytt-toggle-btn" class="ytt-icon-btn" title="Toggle visibility">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/>
              <circle cx="12" cy="12" r="3"/>
            </svg>
          </button>
          <button id="ytt-settings-btn" class="ytt-icon-btn" title="Settings">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <circle cx="12" cy="12" r="3"/>
              <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"/>
            </svg>
          </button>
          <button id="ytt-close-btn" class="ytt-icon-btn" title="Close panel">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <line x1="18" y1="6" x2="6" y2="18"/>
              <line x1="6" y1="6" x2="18" y2="18"/>
            </svg>
          </button>
        </div>
      </div>

      <!-- Settings Panel (hidden by default) -->
      <div id="ytt-settings-panel" class="ytt-settings-panel" style="display:none;">
        <h3>Settings</h3>
        <label for="ytt-api-key">Gemini API Key</label>
        <div class="ytt-api-key-row">
          <input type="password" id="ytt-api-key" placeholder="Enter your Gemini API key..." />
          <button id="ytt-save-api-key" class="ytt-btn ytt-btn-primary">Save</button>
        </div>
        <p class="ytt-hint">Get a free API key at <a href="https://aistudio.google.com/apikey" target="_blank">Google AI Studio</a></p>
        <button id="ytt-settings-close" class="ytt-btn ytt-btn-secondary">Close Settings</button>
      </div>

      <!-- Tabs -->
      <div class="ytt-tabs">
        <button class="ytt-tab active" data-tab="transcription">Transcription</button>
        <button class="ytt-tab" data-tab="summary">Summary</button>
      </div>

      <!-- Big Action Button -->
      <div id="ytt-action-bar" class="ytt-action-bar">
        <button id="ytt-get-transcription-btn" class="ytt-btn ytt-btn-get">GET TRANSCRIPTION</button>
      </div>

      <!-- Language selector (hidden until transcript loaded) -->
      <div id="ytt-lang-bar" class="ytt-lang-bar" style="display:none;">
        <div class="ytt-lang-selector">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <circle cx="12" cy="12" r="10"/>
            <line x1="2" y1="12" x2="22" y2="12"/>
            <path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/>
          </svg>
          <select id="ytt-lang-select">
            <option value="">Auto</option>
          </select>
        </div>
        <div class="ytt-action-buttons">
          <button id="ytt-search-btn" class="ytt-icon-btn" title="Search transcript">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <circle cx="11" cy="11" r="8"/>
              <line x1="21" y1="21" x2="16.65" y2="16.65"/>
            </svg>
          </button>
          <button id="ytt-copy-btn" class="ytt-icon-btn" title="Copy transcript">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <rect x="9" y="9" width="13" height="13" rx="2" ry="2"/>
              <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>
            </svg>
          </button>
          <button id="ytt-download-btn" class="ytt-icon-btn" title="Download transcript">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
              <polyline points="7 10 12 15 17 10"/>
              <line x1="12" y1="15" x2="12" y2="3"/>
            </svg>
          </button>
        </div>
      </div>

      <!-- Search Bar (hidden by default) -->
      <div id="ytt-search-bar" class="ytt-search-bar" style="display:none;">
        <input type="text" id="ytt-search-input" placeholder="Search transcript..." />
        <span id="ytt-search-count"></span>
      </div>

      <!-- Content Area -->
      <div id="ytt-content" class="ytt-content">
        <div id="ytt-transcription-tab" class="ytt-tab-content active">
          <div id="ytt-transcript-list" class="ytt-transcript-list">
          </div>
        </div>
        <div id="ytt-summary-tab" class="ytt-tab-content">
          <div id="ytt-summary-content" class="ytt-summary-content">
            <div class="ytt-placeholder">
              <p>Load transcript first, then generate a summary.</p>
              <button id="ytt-summarize-btn" class="ytt-btn ytt-btn-primary" disabled>Generate Summary</button>
            </div>
          </div>
        </div>
      </div>
    `;

    return panel;
  }

  // ============================================================
  // EVENT LISTENERS
  // ============================================================
  function setupEventListeners() {
    // Toggle panel from extension icon click
    document.addEventListener('yt-to-text-toggle', () => {
      const panel = document.getElementById('ytt-panel');
      if (panel) {
        panelVisible = !panelVisible;
        panel.style.display = panelVisible ? 'block' : 'none';
      }
    });

    // Close button
    document.getElementById('ytt-close-btn').addEventListener('click', () => {
      const panel = document.getElementById('ytt-panel');
      if (panel) {
        panelVisible = false;
        panel.style.display = 'none';
      }
    });

    // Toggle visibility button (collapse/expand content)
    document.getElementById('ytt-toggle-btn').addEventListener('click', () => {
      const content = document.getElementById('ytt-content');
      const langBar = document.getElementById('ytt-lang-bar');
      const actionBar = document.getElementById('ytt-action-bar');
      const searchBar = document.getElementById('ytt-search-bar');
      const tabs = document.querySelector('#ytt-panel .ytt-tabs');
      const isHidden = content.style.display === 'none';
      content.style.display = isHidden ? 'block' : 'none';
      if (langBar) langBar.style.display = isHidden && transcriptData ? 'flex' : 'none';
      if (actionBar) actionBar.style.display = isHidden ? 'block' : 'none';
      if (searchBar) searchBar.style.display = 'none';
      if (tabs) tabs.style.display = isHidden ? 'flex' : 'none';
    });

    // Settings
    document.getElementById('ytt-settings-btn').addEventListener('click', () => {
      const panel = document.getElementById('ytt-settings-panel');
      panel.style.display = panel.style.display === 'none' ? 'block' : 'none';
      chrome.runtime.sendMessage({ action: 'getApiKey' }, (response) => {
        if (response && response.apiKey) {
          document.getElementById('ytt-api-key').value = response.apiKey;
        }
      });
    });

    document.getElementById('ytt-settings-close').addEventListener('click', () => {
      document.getElementById('ytt-settings-panel').style.display = 'none';
    });

    document.getElementById('ytt-save-api-key').addEventListener('click', () => {
      const key = document.getElementById('ytt-api-key').value.trim();
      chrome.runtime.sendMessage({ action: 'saveApiKey', apiKey: key }, () => {
        showToast('API key saved!');
        document.getElementById('ytt-settings-panel').style.display = 'none';
      });
    });

    // Tabs
    document.querySelectorAll('#ytt-panel .ytt-tab').forEach(tab => {
      tab.addEventListener('click', () => {
        document.querySelectorAll('#ytt-panel .ytt-tab').forEach(t => t.classList.remove('active'));
        document.querySelectorAll('#ytt-panel .ytt-tab-content').forEach(c => c.classList.remove('active'));
        tab.classList.add('active');
        document.getElementById(`ytt-${tab.dataset.tab}-tab`).classList.add('active');
      });
    });

    // GET TRANSCRIPTION button
    document.getElementById('ytt-get-transcription-btn').addEventListener('click', loadTranscript);

    // Language selector
    document.getElementById('ytt-lang-select').addEventListener('change', (e) => {
      currentLang = e.target.value;
      loadTranscript();
    });

    // Summarize button
    document.getElementById('ytt-summarize-btn').addEventListener('click', generateSummary);

    // Copy button
    document.getElementById('ytt-copy-btn').addEventListener('click', copyTranscript);

    // Download button
    document.getElementById('ytt-download-btn').addEventListener('click', downloadTranscript);

    // Search toggle
    document.getElementById('ytt-search-btn').addEventListener('click', () => {
      const bar = document.getElementById('ytt-search-bar');
      bar.style.display = bar.style.display === 'none' ? 'flex' : 'none';
      if (bar.style.display === 'flex') {
        document.getElementById('ytt-search-input').focus();
      }
    });

    document.getElementById('ytt-search-input').addEventListener('input', (e) => {
      searchQuery = e.target.value.toLowerCase();
      renderTranscript();
    });
  }

  // ============================================================
  // VIDEO DETECTION
  // ============================================================
  function getVideoId() {
    const urlParams = new URLSearchParams(window.location.search);
    return urlParams.get('v');
  }

  function detectVideoChange() {
    const checkVideo = () => {
      const newVideoId = getVideoId();
      if (newVideoId && newVideoId !== currentVideoId) {
        currentVideoId = newVideoId;
        transcriptData = null;
        currentLang = '';
        resetUI();
      }
    };

    checkVideo();

    // Watch for YouTube SPA navigation
    const observer = new MutationObserver(() => {
      checkVideo();
      if (!document.getElementById('ytt-panel')) {
        injectPanel();
      }
    });
    observer.observe(document.querySelector('title') || document.head, {
      childList: true,
      subtree: true,
      characterData: true
    });

    window.addEventListener('yt-navigate-finish', () => {
      checkVideo();
      setTimeout(() => {
        if (!document.getElementById('ytt-panel')) {
          injectPanel();
        }
      }, 1000);
    });
  }

  function resetUI() {
    const listEl = document.getElementById('ytt-transcript-list');
    if (listEl) listEl.innerHTML = '';

    const actionBar = document.getElementById('ytt-action-bar');
    if (actionBar) actionBar.style.display = 'block';

    const langBar = document.getElementById('ytt-lang-bar');
    if (langBar) langBar.style.display = 'none';

    const getBtn = document.getElementById('ytt-get-transcription-btn');
    if (getBtn) {
      getBtn.textContent = 'GET TRANSCRIPTION';
      getBtn.disabled = false;
    }

    const summaryContent = document.getElementById('ytt-summary-content');
    if (summaryContent) {
      summaryContent.innerHTML = `
        <div class="ytt-placeholder">
          <p>Load transcript first, then generate a summary.</p>
          <button id="ytt-summarize-btn" class="ytt-btn ytt-btn-primary" disabled>Generate Summary</button>
        </div>
      `;
      document.getElementById('ytt-summarize-btn').addEventListener('click', generateSummary);
    }

    const langSelect = document.getElementById('ytt-lang-select');
    if (langSelect) langSelect.innerHTML = '<option value="">Auto</option>';
  }

  // ============================================================
  // TRANSCRIPT LOADING (now done directly in content script!)
  // ============================================================
  async function loadTranscript() {
    if (!currentVideoId) {
      showToast('No video detected.');
      return;
    }

    const getBtn = document.getElementById('ytt-get-transcription-btn');
    if (getBtn) {
      getBtn.textContent = 'LOADING...';
      getBtn.disabled = true;
    }

    try {
      // Fetch transcript directly from page context (has user's cookies!)
      const response = await fetchTranscriptData(currentVideoId, currentLang);

      transcriptData = response;

      // Populate language selector
      const langSelect = document.getElementById('ytt-lang-select');
      langSelect.innerHTML = '';
      response.languages.forEach(lang => {
        const option = document.createElement('option');
        option.value = lang.code;
        option.textContent = lang.code.toUpperCase() + (lang.isGenerated ? ' (auto)' : '');
        if (lang.code === response.selectedLanguage) option.selected = true;
        langSelect.appendChild(option);
      });
      currentLang = response.selectedLanguage;

      // Hide the big GET button, show the lang/action bar
      const actionBar = document.getElementById('ytt-action-bar');
      if (actionBar) actionBar.style.display = 'none';

      const langBar = document.getElementById('ytt-lang-bar');
      if (langBar) langBar.style.display = 'flex';

      // Enable summarize button
      const sumBtn = document.getElementById('ytt-summarize-btn');
      if (sumBtn) sumBtn.disabled = false;

      renderTranscript();
      showToast(`Transcript loaded! (${response.transcript.length} segments)`);
    } catch (err) {
      if (getBtn) {
        getBtn.textContent = 'RETRY';
        getBtn.disabled = false;
      }
      showToast(err.message);
      console.error('[YTT] Transcript loading error:', err);
    }
  }

  // ============================================================
  // RENDER TRANSCRIPT
  // ============================================================
  function renderTranscript() {
    if (!transcriptData || !transcriptData.transcript) return;

    const listEl = document.getElementById('ytt-transcript-list');
    listEl.innerHTML = '';

    const items = transcriptData.transcript;
    const searchCountEl = document.getElementById('ytt-search-count');
    let matchCount = 0;

    items.forEach((item) => {
      const matchesSearch = !searchQuery || item.text.toLowerCase().includes(searchQuery);
      if (searchQuery && matchesSearch) matchCount++;

      const div = document.createElement('div');
      div.className = 'ytt-transcript-item' + (matchesSearch ? '' : ' ytt-hidden');

      const timestamp = formatTime(item.start);
      let displayText = escapeHtml(item.text);

      if (searchQuery && matchesSearch) {
        const regex = new RegExp(`(${escapeRegex(searchQuery)})`, 'gi');
        displayText = displayText.replace(regex, '<mark>$1</mark>');
      }

      div.innerHTML = `
        <span class="ytt-timestamp" data-time="${item.start}">${timestamp}</span>
        <span class="ytt-text">${displayText}</span>
      `;

      div.querySelector('.ytt-timestamp').addEventListener('click', () => {
        seekVideo(item.start);
      });

      listEl.appendChild(div);
    });

    if (searchQuery) {
      searchCountEl.textContent = `${matchCount} match${matchCount !== 1 ? 'es' : ''}`;
    } else {
      searchCountEl.textContent = '';
    }
  }

  // ============================================================
  // AI SUMMARY
  // ============================================================
  async function generateSummary() {
    if (!transcriptData || !transcriptData.transcript) {
      showToast('Load transcript first.');
      return;
    }

    const contentEl = document.getElementById('ytt-summary-content');
    contentEl.innerHTML = `
      <div class="ytt-placeholder">
        <div class="ytt-spinner spinning"></div>
        <p>Generating AI summary...</p>
      </div>
    `;

    // Switch to summary tab
    document.querySelectorAll('#ytt-panel .ytt-tab').forEach(t => t.classList.remove('active'));
    document.querySelectorAll('#ytt-panel .ytt-tab-content').forEach(c => c.classList.remove('active'));
    document.querySelector('#ytt-panel .ytt-tab[data-tab="summary"]').classList.add('active');
    document.getElementById('ytt-summary-tab').classList.add('active');

    try {
      const keyResponse = await new Promise((resolve) => {
        chrome.runtime.sendMessage({ action: 'getApiKey' }, resolve);
      });

      if (!keyResponse || !keyResponse.apiKey) {
        contentEl.innerHTML = `
          <div class="ytt-placeholder">
            <p>Gemini API key required for AI summaries.</p>
            <p class="ytt-hint">Click the gear icon to add your free API key from <a href="https://aistudio.google.com/apikey" target="_blank">Google AI Studio</a></p>
            <button id="ytt-open-settings-from-summary" class="ytt-btn ytt-btn-primary">Open Settings</button>
          </div>
        `;
        document.getElementById('ytt-open-settings-from-summary').addEventListener('click', () => {
          document.getElementById('ytt-settings-panel').style.display = 'block';
          chrome.runtime.sendMessage({ action: 'getApiKey' }, (response) => {
            if (response && response.apiKey) {
              document.getElementById('ytt-api-key').value = response.apiKey;
            }
          });
        });
        return;
      }

      const fullText = transcriptData.transcript.map(item =>
        `[${formatTime(item.start)}] ${item.text}`
      ).join('\n');

      const response = await new Promise((resolve, reject) => {
        chrome.runtime.sendMessage(
          { action: 'summarize', text: fullText, apiKey: keyResponse.apiKey },
          (resp) => {
            if (chrome.runtime.lastError) {
              reject(new Error(chrome.runtime.lastError.message));
            } else if (resp && resp.success) {
              resolve(resp.data);
            } else {
              reject(new Error(resp?.error || 'Unknown error'));
            }
          }
        );
      });

      contentEl.innerHTML = `
        <div class="ytt-summary-text">${renderMarkdown(response)}</div>
        <div class="ytt-summary-actions">
          <button id="ytt-copy-summary" class="ytt-btn ytt-btn-secondary">Copy Summary</button>
          <button id="ytt-regenerate" class="ytt-btn ytt-btn-primary">Regenerate</button>
        </div>
      `;

      document.getElementById('ytt-copy-summary').addEventListener('click', () => {
        navigator.clipboard.writeText(response).then(() => showToast('Summary copied!'));
      });

      document.getElementById('ytt-regenerate').addEventListener('click', generateSummary);

    } catch (err) {
      contentEl.innerHTML = `
        <div class="ytt-placeholder">
          <p>${escapeHtml(err.message)}</p>
          <button id="ytt-summarize-btn" class="ytt-btn ytt-btn-primary">Retry</button>
        </div>
      `;
      document.getElementById('ytt-summarize-btn').addEventListener('click', generateSummary);
    }
  }

  // ============================================================
  // COPY & DOWNLOAD
  // ============================================================
  function copyTranscript() {
    if (!transcriptData || !transcriptData.transcript) {
      showToast('No transcript loaded.');
      return;
    }

    const text = transcriptData.transcript.map(item =>
      `[${formatTime(item.start)}] ${item.text}`
    ).join('\n');

    navigator.clipboard.writeText(text).then(() => {
      showToast('Transcript copied to clipboard!');
    }).catch(() => {
      showToast('Failed to copy.');
    });
  }

  function downloadTranscript() {
    if (!transcriptData || !transcriptData.transcript) {
      showToast('No transcript loaded.');
      return;
    }

    const text = transcriptData.transcript.map(item =>
      `[${formatTime(item.start)}] ${item.text}`
    ).join('\n');

    const title = transcriptData.videoTitle || 'transcript';
    const blob = new Blob([text], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${sanitizeFilename(title)}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    showToast('Transcript downloaded!');
  }

  // ============================================================
  // UTILITY FUNCTIONS
  // ============================================================
  function formatTime(seconds) {
    const h = Math.floor(seconds / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    const s = Math.floor(seconds % 60);
    if (h > 0) {
      return `${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
    }
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  }

  function seekVideo(time) {
    const video = document.querySelector('video');
    if (video) {
      video.currentTime = time;
      video.play();
    }
  }

  function escapeHtml(str) {
    const div = document.createElement('div');
    div.textContent = str;
    return div.innerHTML;
  }

  function escapeRegex(str) {
    return str.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  }

  function sanitizeFilename(name) {
    return name.replace(/[^a-z0-9\s\-_]/gi, '').replace(/\s+/g, '_').substring(0, 100);
  }

  function renderMarkdown(text) {
    return text
      .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
      .replace(/\*(.+?)\*/g, '<em>$1</em>')
      .replace(/^### (.+)$/gm, '<h4>$1</h4>')
      .replace(/^## (.+)$/gm, '<h3>$1</h3>')
      .replace(/^# (.+)$/gm, '<h2>$1</h2>')
      .replace(/^\* (.+)$/gm, '<li>$1</li>')
      .replace(/^- (.+)$/gm, '<li>$1</li>')
      .replace(/(<li>.*<\/li>)/gs, '<ul>$1</ul>')
      .replace(/<\/ul>\s*<ul>/g, '')
      .replace(/\n\n/g, '</p><p>')
      .replace(/\n/g, '<br>')
      .replace(/^/, '<p>')
      .replace(/$/, '</p>');
  }

  function showToast(message) {
    const panel = document.getElementById('ytt-panel');
    if (!panel) return;

    const existing = document.getElementById('ytt-toast');
    if (existing) existing.remove();

    const toast = document.createElement('div');
    toast.id = 'ytt-toast';
    toast.className = 'ytt-toast';
    toast.textContent = message;
    panel.appendChild(toast);

    setTimeout(() => toast.classList.add('show'), 10);
    setTimeout(() => {
      toast.classList.remove('show');
      setTimeout(() => toast.remove(), 300);
    }, 2500);
  }

  // ============================================================
  // START
  // ============================================================
  injectPanel();

})();
