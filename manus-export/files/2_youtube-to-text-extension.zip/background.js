// Background service worker for YouTube To Text extension

// Handle extension icon click - toggle sidebar on YouTube pages
chrome.action.onClicked.addListener(async (tab) => {
  if (tab.url && tab.url.includes('youtube.com/watch')) {
    try {
      await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: () => {
          const event = new CustomEvent('yt-to-text-toggle');
          document.dispatchEvent(event);
        }
      });
    } catch (err) {
      console.error('Failed to toggle sidebar:', err);
    }
  }
});

// Listen for messages from content script
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'fetchTranscript') {
    fetchTranscriptData(request.videoId, request.lang)
      .then(data => sendResponse({ success: true, data }))
      .catch(err => sendResponse({ success: false, error: err.message }));
    return true; // Keep message channel open for async response
  }

  if (request.action === 'summarize') {
    summarizeWithAI(request.text, request.apiKey)
      .then(data => sendResponse({ success: true, data }))
      .catch(err => sendResponse({ success: false, error: err.message }));
    return true;
  }

  if (request.action === 'getApiKey') {
    chrome.storage.sync.get(['geminiApiKey'], (result) => {
      sendResponse({ apiKey: result.geminiApiKey || '' });
    });
    return true;
  }

  if (request.action === 'saveApiKey') {
    chrome.storage.sync.set({ geminiApiKey: request.apiKey }, () => {
      sendResponse({ success: true });
    });
    return true;
  }
});

// Fetch transcript data using YouTube's innertube API
async function fetchTranscriptData(videoId, lang = 'en') {
  const videoUrl = `https://www.youtube.com/watch?v=${videoId}`;

  // Step 1: Fetch the video page to get innertube data
  const pageResponse = await fetch(videoUrl);
  const html = await pageResponse.text();

  // Extract the ytInitialPlayerResponse which contains caption info
  // Try multiple extraction methods for robustness
  let playerResponse;
  
  // Method 1: Try ytInitialPlayerResponse
  let playerResponseMatch = html.match(/var\s+ytInitialPlayerResponse\s*=\s*/);
  if (playerResponseMatch) {
    const startIdx = playerResponseMatch.index + playerResponseMatch[0].length;
    try {
      playerResponse = extractJsonObject(html, startIdx);
    } catch (e) {
      // Fall through to method 2
    }
  }

  // Method 2: Try to find captions in ytInitialData
  if (!playerResponse) {
    const match2 = html.match(/"captions"\s*:\s*\{"playerCaptionsTracklistRenderer/);
    if (match2) {
      // Extract just the captions block
      const captionsStart = match2.index;
      // Find the captionTracks array
      const tracksMatch = html.substring(captionsStart).match(/"captionTracks"\s*:\s*(\[.+?\])/);
      if (tracksMatch) {
        try {
          const tracks = JSON.parse(tracksMatch[1]);
          playerResponse = {
            captions: {
              playerCaptionsTracklistRenderer: {
                captionTracks: tracks
              }
            }
          };
        } catch(e) { /* fall through */ }
      }
    }
  }

  // Method 3: Regex-based extraction as fallback
  if (!playerResponse) {
    const m = html.match(/ytInitialPlayerResponse\s*=\s*({.*?});\s*(?:var|<\/script)/);
    if (m) {
      try {
        playerResponse = JSON.parse(m[1]);
      } catch(e) { /* fall through */ }
    }
  }

  if (!playerResponse) {
    throw new Error('Could not extract player response from page. The video may be restricted or unavailable.');
  }

  const captions = playerResponse?.captions?.playerCaptionsTracklistRenderer;
  if (!captions || !captions.captionTracks || captions.captionTracks.length === 0) {
    throw new Error('No captions available for this video.');
  }

  // Get available languages
  const availableLanguages = captions.captionTracks.map(track => ({
    code: track.languageCode,
    name: track.name?.simpleText || track.languageCode,
    isGenerated: track.kind === 'asr',
    baseUrl: track.baseUrl
  }));

  // Find the requested language track, fallback to first available
  let selectedTrack = captions.captionTracks.find(t => t.languageCode === lang);
  if (!selectedTrack) {
    selectedTrack = captions.captionTracks[0];
  }

  // Step 2: Fetch the actual transcript XML
  const transcriptUrl = selectedTrack.baseUrl;
  const transcriptResponse = await fetch(transcriptUrl);
  const xml = await transcriptResponse.text();

  // Step 3: Parse the XML
  const parser = new DOMParser();
  const doc = parser.parseFromString(xml, 'text/xml');
  const textElements = doc.querySelectorAll('text');

  const transcript = [];
  textElements.forEach(el => {
    const start = parseFloat(el.getAttribute('start'));
    const duration = parseFloat(el.getAttribute('dur') || '0');
    let text = el.textContent || '';
    // Decode HTML entities
    text = text.replace(/&amp;/g, '&')
               .replace(/&lt;/g, '<')
               .replace(/&gt;/g, '>')
               .replace(/&quot;/g, '"')
               .replace(/&#39;/g, "'")
               .replace(/\n/g, ' ')
               .trim();

    if (text) {
      transcript.push({
        text,
        start,
        duration,
        end: start + duration
      });
    }
  });

  // Get video title
  const titleMatch = html.match(/<title>([^<]+)<\/title>/);
  const videoTitle = titleMatch ? titleMatch[1].replace(' - YouTube', '').trim() : 'YouTube Video';

  return {
    transcript,
    languages: availableLanguages,
    selectedLanguage: selectedTrack.languageCode,
    videoTitle
  };
}

// Summarize transcript using Gemini API
async function summarizeWithAI(text, apiKey) {
  if (!apiKey) {
    throw new Error('Please set your Gemini API key in the extension settings.');
  }

  const prompt = `You are a helpful assistant that summarizes YouTube video transcripts. Please provide:

1. A concise **Summary** (2-3 paragraphs) of the main content.
2. **Key Points** (5-8 bullet points) highlighting the most important takeaways.

Here is the transcript:

${text.substring(0, 30000)}`;

  const response = await fetch(
    `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${apiKey}`,
    {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        contents: [{
          parts: [{ text: prompt }]
        }],
        generationConfig: {
          temperature: 0.3,
          maxOutputTokens: 2048
        }
      })
    }
  );

  if (!response.ok) {
    const errData = await response.json().catch(() => ({}));
    throw new Error(errData.error?.message || `API request failed with status ${response.status}`);
  }

  const data = await response.json();
  const result = data.candidates?.[0]?.content?.parts?.[0]?.text;

  if (!result) {
    throw new Error('No summary generated. Please try again.');
  }

  return result;
}

// Helper: extract a JSON object starting at a given index in a string
function extractJsonObject(str, startIdx) {
  let depth = 0;
  let inString = false;
  let escape = false;
  let start = -1;

  for (let i = startIdx; i < str.length && i < startIdx + 500000; i++) {
    const ch = str[i];

    if (escape) {
      escape = false;
      continue;
    }

    if (ch === '\\' && inString) {
      escape = true;
      continue;
    }

    if (ch === '"') {
      inString = !inString;
      continue;
    }

    if (inString) continue;

    if (ch === '{') {
      if (depth === 0) start = i;
      depth++;
    } else if (ch === '}') {
      depth--;
      if (depth === 0) {
        return JSON.parse(str.substring(start, i + 1));
      }
    }
  }

  throw new Error('Could not extract JSON object');
}
