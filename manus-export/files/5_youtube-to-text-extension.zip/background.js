// Background service worker for YouTube To Text extension
// Only handles: AI summarization and API key storage
// Transcript extraction is now done in the content script (page context)

// Handle extension icon click - toggle panel on YouTube pages
chrome.action.onClicked.addListener(async (tab) => {
  if (tab.url && tab.url.includes('youtube.com/watch')) {
    try {
      await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: () => {
          const event = new CustomEvent('yt-to-text-toggle');
          document.dispatchEvent(event);
        }
      });
    } catch (err) {
      console.error('Failed to toggle panel:', err);
    }
  }
});

// Listen for messages from content script
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'summarize') {
    summarizeWithAI(request.text, request.apiKey)
      .then(data => sendResponse({ success: true, data }))
      .catch(err => sendResponse({ success: false, error: err.message }));
    return true;
  }

  if (request.action === 'getApiKey') {
    chrome.storage.sync.get(['geminiApiKey'], (result) => {
      sendResponse({ apiKey: result.geminiApiKey || '' });
    });
    return true;
  }

  if (request.action === 'saveApiKey') {
    chrome.storage.sync.set({ geminiApiKey: request.apiKey }, () => {
      sendResponse({ success: true });
    });
    return true;
  }
});

// Summarize transcript using Gemini API
async function summarizeWithAI(text, apiKey) {
  if (!apiKey) {
    throw new Error('Please set your Gemini API key in the extension settings.');
  }

  const prompt = `You are a helpful assistant that summarizes YouTube video transcripts. Please provide:

1. A concise **Summary** (2-3 paragraphs) of the main content.
2. **Key Points** (5-8 bullet points) highlighting the most important takeaways.

Here is the transcript:

${text.substring(0, 30000)}`;

  const response = await fetch(
    `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${apiKey}`,
    {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        contents: [{
          parts: [{ text: prompt }]
        }],
        generationConfig: {
          temperature: 0.3,
          maxOutputTokens: 2048
        }
      })
    }
  );

  if (!response.ok) {
    const errData = await response.json().catch(() => ({}));
    throw new Error(errData.error?.message || `API request failed with status ${response.status}`);
  }

  const data = await response.json();
  const result = data.candidates?.[0]?.content?.parts?.[0]?.text;

  if (!result) {
    throw new Error('No summary generated. Please try again.');
  }

  return result;
}
