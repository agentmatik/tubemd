// TubeMD - Background Service Worker
// Handles: AI summarization (multi-provider), settings storage, icon click toggle
// Version: 1.0.0

// ============================================================
// ICON CLICK - Toggle inline panel on YouTube pages
// Since we now have a popup, this only fires via keyboard shortcut or programmatic call
// ============================================================
chrome.commands?.onCommand?.addListener((command) => {
  if (command === 'toggle-panel') {
    chrome.tabs.query({ active: true, currentWindow: true }, ([tab]) => {
      if (tab?.url?.includes('youtube.com/watch')) {
        chrome.scripting.executeScript({
          target: { tabId: tab.id },
          func: () => document.dispatchEvent(new CustomEvent('yt-to-text-toggle'))
        });
      }
    });
  }
});

// ============================================================
// MESSAGE HANDLER
// ============================================================
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  switch (request.action) {
    case 'summarize':
      handleSummarize(request)
        .then(data => sendResponse({ success: true, data }))
        .catch(err => sendResponse({ success: false, error: err.message }));
      return true;

    case 'getSettings':
      getSettings().then(sendResponse);
      return true;

    case 'saveSettings':
      saveSettings(request.settings).then(() => sendResponse({ success: true }));
      return true;

    case 'getApiKey':
      // Legacy support for inline panel
      getSettings().then(s => {
        const provider = s.aiProvider || 'gemini';
        sendResponse({ apiKey: s.apiKeys?.[provider] || '' });
      });
      return true;

    case 'saveApiKey':
      // Legacy support for inline panel
      getSettings().then(s => {
        if (!s.apiKeys) s.apiKeys = {};
        s.apiKeys[s.aiProvider || 'gemini'] = request.apiKey;
        saveSettings(s).then(() => sendResponse({ success: true }));
      });
      return true;
  }
});

// ============================================================
// SETTINGS MANAGEMENT
// ============================================================
const DEFAULT_SETTINGS = {
  aiProvider: 'gemini',
  apiKeys: { gemini: '', openai: '', claude: '' },
  defaultFormat: 'markdown',
  theme: 'light'
};

async function getSettings() {
  return new Promise(resolve => {
    chrome.storage.sync.get(['tubeMdSettings'], (result) => {
      resolve({ ...DEFAULT_SETTINGS, ...(result.tubeMdSettings || {}) });
    });
  });
}

async function saveSettings(settings) {
  return new Promise(resolve => {
    chrome.storage.sync.set({ tubeMdSettings: settings }, resolve);
  });
}

// ============================================================
// AI SUMMARIZATION - Multi-provider
// ============================================================
async function handleSummarize(request) {
  const { text, provider, apiKey } = request;

  if (!apiKey) {
    throw new Error(`No API key provided. Please configure your ${provider} API key in Settings.`);
  }

  const truncatedText = text.substring(0, 30000);

  const systemPrompt = `You are a helpful assistant that summarizes YouTube video transcripts. Provide:
1. A concise **Summary** (2-3 paragraphs) of the main content.
2. **Key Points** (5-8 bullet points) highlighting the most important takeaways.
3. **Topics Covered** - a brief list of main topics discussed.`;

  switch (provider) {
    case 'gemini':
      return await summarizeWithGemini(truncatedText, apiKey, systemPrompt);
    case 'openai':
      return await summarizeWithOpenAI(truncatedText, apiKey, systemPrompt);
    case 'claude':
      return await summarizeWithClaude(truncatedText, apiKey, systemPrompt);
    default:
      throw new Error(`Unknown AI provider: ${provider}`);
  }
}

// --- Gemini ---
async function summarizeWithGemini(text, apiKey, systemPrompt) {
  const response = await fetch(
    `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${apiKey}`,
    {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        contents: [{
          parts: [{ text: `${systemPrompt}\n\nHere is the transcript:\n\n${text}` }]
        }],
        generationConfig: { temperature: 0.3, maxOutputTokens: 2048 }
      })
    }
  );

  if (!response.ok) {
    const err = await response.json().catch(() => ({}));
    throw new Error(err.error?.message || `Gemini API error: ${response.status}`);
  }

  const data = await response.json();
  const result = data.candidates?.[0]?.content?.parts?.[0]?.text;
  if (!result) throw new Error('Gemini returned no content.');
  return result;
}

// --- OpenAI (ChatGPT) ---
async function summarizeWithOpenAI(text, apiKey, systemPrompt) {
  const response = await fetch('https://api.openai.com/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${apiKey}`
    },
    body: JSON.stringify({
      model: 'gpt-4o-mini',
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: `Here is the transcript:\n\n${text}` }
      ],
      temperature: 0.3,
      max_tokens: 2048
    })
  });

  if (!response.ok) {
    const err = await response.json().catch(() => ({}));
    throw new Error(err.error?.message || `OpenAI API error: ${response.status}`);
  }

  const data = await response.json();
  const result = data.choices?.[0]?.message?.content;
  if (!result) throw new Error('OpenAI returned no content.');
  return result;
}

// --- Anthropic (Claude) ---
async function summarizeWithClaude(text, apiKey, systemPrompt) {
  const response = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-api-key': apiKey,
      'anthropic-version': '2023-06-01',
      'anthropic-dangerous-direct-browser-access': 'true'
    },
    body: JSON.stringify({
      model: 'claude-sonnet-4-20250514',
      max_tokens: 2048,
      system: systemPrompt,
      messages: [
        { role: 'user', content: `Here is the transcript:\n\n${text}` }
      ]
    })
  });

  if (!response.ok) {
    const err = await response.json().catch(() => ({}));
    throw new Error(err.error?.message || `Claude API error: ${response.status}`);
  }

  const data = await response.json();
  const result = data.content?.[0]?.text;
  if (!result) throw new Error('Claude returned no content.');
  return result;
}
